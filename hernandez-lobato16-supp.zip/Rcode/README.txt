This folder contains the R code of the 3 methods described in the main paper
SEP, SVI and GFITC. The code can be evaluated in the MNIST dataset. For that,
the first step is to generate the data. For this, you should place the MNIST 
data files

t10k-images-idx3-ubyte
t10k-labels-idx1-ubyte
train-images-idx3-ubyte
train-labels-idx1-ubyte

in the "data" folder. You can simply download them from 

http://yann.lecun.com/exdb/mnist/

Then, you should go to that folder and run 

R --no-save < getData.R 

That will generate the MNIST data used by the different experiments.

Then, in the folder "experiments"  there is one sub-folder per method with one
script inside each sub-folder of type "simulate_ ...". Simply run that script 
using 

R --no-save < name_of_the_script

That will simulate the corresponding method and the results will be stored
in the sub-folder results.

Note that several R packages have to be installed for the code to work properly.
You can install them using the typical R package installing tool.

In these experiments the GFITC approximation performs similar to the BATCH 
implementation of SEP in spite of running EP until convergence. The reason 
is that GFITC uses a quasi-Newton method, i.e., L-BFGS-B to update the 
hyper-parameters. In this problem this gives a significantly better 
convergence rate over the simple gradient ascent steps followed by the 
batch implementation of SEP. Of course, GFITC  is limited in the sense that
it does not allow for distributed computations nor stochastic optimization.

Importantly, the doMC package that is used to simulate distributed training
allows to run for loops in parallel. However, for this, the R process is forked
which means that it will create several processes with the same memory requirements.
The consequence is that this type of simulation is very demanding in terms of memory.




