# Global variable that indicates the current repetition

rep <- 1
t0 <- NULL
global_solution_EP <- NULL

##
# Function which computes the cholesky decomposition of the inverse
# of a particular matrix.
#
# @param	M	m x m positive definite matrix.
#
# @return	L	m x m upper triangular matrix such that
#			M^-1 = L %*% t(L)
#

cholInverse <- function(M) { rot180(forwardsolve(t(chol(rot180(M))), diag(nrow(M)))) }

##
# Function which rotates a matrix 180 degreees.
#

rot180 <- function(M) { matrix(rev(as.double(M)), nrow(M), ncol(M)) }

##
# This function computes the covariance matrix for the GP
#

kernel <- function(X, l, sigma0, sigma) {
	X <- X / matrix(sqrt(l), nrow(X), ncol(X), byrow = TRUE)
	distance <- as.matrix(dist(X))^2
	sigma * exp(-0.5 * distance) + diag(sigma0, nrow(X)) + diag(rep(1e-10, nrow(X)))
}

##
# Function which computes the kernel matrix between the observed data and the test data
#

kernel_nm <- function(X, Xnew, l, sigma) {

	X <- X / matrix(sqrt(l), nrow(X), ncol(X), byrow = TRUE)	
	Xnew <- Xnew / matrix(sqrt(l), nrow(Xnew), ncol(Xnew), byrow = TRUE)
	n <- nrow(X)
	m <- nrow(Xnew)
	Q <- matrix(apply(X^2, 1, sum), n, m)
	Qbar <- matrix(apply(Xnew^2, 1, sum), n, m, byrow = T)
	distance <- Qbar + Q - 2 * X %*% t(Xnew)
	sigma * exp(-0.5 * distance)
}

##
# Function which computes the diagonal of the kernel matrix for the data
# points.
#
# @param	X 		n x d matrix with the n data points.
# @param	sigma		scalar with the amplitude of the GP.
# @param	sigma0		scalar with the noise level in the GP.
#
# @return	diagKnn		n-dimensional vector with the diagonal of the
#				kernel matrix for the data points.
#

computeDiagKernel <- function(X, sigma, sigma0) { rep(sigma, nrow(X)) + 1e-10 + sigma0 }

##
# Function that initializes the struture with the problem information.
#
# @param	X	n x d matrix with the data points.
# @param	Xbar	m x d matrix with the pseudo inputs.
# @param	sigma	scalar with the log-amplitude of the GP.
# @param	sigma0	scalar with the log-noise level in the GP.
# @param	l	d-dimensional vector with the log-lengthscales.
# 
# @return	gFITCinfo	List with the problem information 
#

initialize_kernel_FITC <- function(X, Xbar, sigma, sigma0, l) {

	# We initialize the structure with the data and the kernel
	# hyper-parameters

	gFITCinfo <- list()
	gFITCinfo$X <- X
	gFITCinfo$Xbar <- Xbar
	gFITCinfo$m <- nrow(Xbar)
	gFITCinfo$d <- ncol(Xbar)
	gFITCinfo$n <- nrow(X)
	gFITCinfo$sigma <- sigma
	gFITCinfo$sigma0 <- sigma0
	gFITCinfo$l <- l

	# We compute the kernel matrices

	gFITCinfo$Kmm <- kernel(Xbar, gFITCinfo$l, gFITCinfo$sigma0, gFITCinfo$sigma)
	gFITCinfo$Knm <- kernel_nm(X, Xbar, gFITCinfo$l, gFITCinfo$sigma)
	gFITCinfo$P <- gFITCinfo$Knm
	gFITCinfo$R <- cholInverse(gFITCinfo$Kmm)
	gFITCinfo$PRt <- gFITCinfo$P %*% t(gFITCinfo$R)

	# We compute the diagonal matrices

	gFITCinfo$diagKnn <- computeDiagKernel(X, gFITCinfo$sigma, gFITCinfo$sigma0)
	gFITCinfo$D <- gFITCinfo$diagKnn - (gFITCinfo$PRt)^2 %*% rep(1, gFITCinfo$m)

	gFITCinfo
}

##
# Function that computes the marginal means and variances of the product
# of the FITC prior and a multivariate Gaussian density with diagonal
# correlation matrix.
#
# @param	gFITCinfo	List with the problem information
#				(see initializegFITCinfo).
# @param	f1Hat		list with n-dimensional vector with the inverse
#				variances times the mean of the Gaussian and the invese variances
#				approximation to the likelihood factor.
#
# @return	ret		A list with the marginal means and variances.
#

computeTitledDistribution <- function(gFITCinfo, f1Hat) {

	Dnew <- gFITCinfo$D / (1 + gFITCinfo$D * f1Hat$eta2)
	Pnew <- matrix(1 / (1 + gFITCinfo$D * f1Hat$eta2), gFITCinfo$n,
		gFITCinfo$m) * gFITCinfo$P

	Rnew <- backsolve(rot180(t(chol(rot180(diag(gFITCinfo$m) +
		t(gFITCinfo$PRt) %*% (matrix(f1Hat$eta2 / (1 + gFITCinfo$D *
		f1Hat$eta2), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$PRt))))),
		gFITCinfo$R)

	aNew <- Dnew * f1Hat$eta1
	gammaNew <- t(Rnew) %*% (Rnew %*% (t(Pnew) %*% f1Hat$eta1))

	# We obtain the new marginal means

	vNew <- as.double(Dnew + (Pnew %*% t(Rnew))^2 %*% rep(1, gFITCinfo$m))
	mNew <- as.double(aNew) + as.double(Pnew %*% gammaNew)

	list(mNew = mNew, vNew = vNew)
}

##
# Function that computes classes and probabilities of the labels of test data
#
# ret is the list returned by EP
#

#predict <- function(Ytest, Xtest, ret) {
#
#	# We compute the FITC prediction
#
#	gFITCinfo <- ret$gFITCinfo
#	muTilde <- ret$f1Hat$eta1
#	tauTilde <- ret$f1Hat$eta2
#
#	pStar <- kernel_nm(Xtest, gFITCinfo$Xbar, gFITCinfo$l, gFITCinfo$sigma)
#	dStar <- computeDiagKernel(Xtest, gFITCinfo$sigma, gFITCinfo$sigma0) - (pStar %*%t(gFITCinfo$R))^2 %*% rep(1, gFITCinfo$m)
#
#	Dnew <- gFITCinfo$D / (1 + gFITCinfo$D * tauTilde)
#	Pnew <- matrix(1 / (1 + gFITCinfo$D * tauTilde), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$P
#
#	Rnew <- backsolve(rot180(t(chol(rot180(diag(gFITCinfo$m) + t(gFITCinfo$PRt) %*% (matrix(tauTilde / (1 + gFITCinfo$D *
#		tauTilde), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$PRt))))), gFITCinfo$R)
#
#	gammaNew <- t(Rnew) %*% (Rnew %*% (t(Pnew) %*% muTilde))
#
#	# We obtain the new marginals
#
#	mPrediction <- pStar %*% gammaNew 
#	vPrediction <- dStar + (pStar %*% t(Rnew))^2 %*% rep(1, gFITCinfo$m)
#	
#	labels <- sign(mPrediction)
#	log_probs <- pnorm(Ytest * mPrediction / sqrt(vPrediction), log.p = TRUE)
#	error <- mean(labels != Ytest)
#
#	list(labels = labels, log_probs = log_probs, error = error)
#}

predict <- function(Xtest, ret) {

	# We compute the FITC prediction

	gFITCinfo <- ret$gFITCinfo
	muTilde <- ret$f1Hat$eta1
	tauTilde <- ret$f1Hat$eta2

	pStar <- kernel_nm(Xtest, gFITCinfo$Xbar, gFITCinfo$l, gFITCinfo$sigma)
	dStar <- computeDiagKernel(Xtest, gFITCinfo$sigma, gFITCinfo$sigma0) - (pStar %*%t(gFITCinfo$R))^2 %*% rep(1, gFITCinfo$m)

	Dnew <- gFITCinfo$D / (1 + gFITCinfo$D * tauTilde)
	Pnew <- matrix(1 / (1 + gFITCinfo$D * tauTilde), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$P

	Rnew <- backsolve(rot180(t(chol(rot180(diag(gFITCinfo$m) + t(gFITCinfo$PRt) %*% (matrix(tauTilde / (1 + gFITCinfo$D *
		tauTilde), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$PRt))))), gFITCinfo$R)

	gammaNew <- t(Rnew) %*% (Rnew %*% (t(Pnew) %*% muTilde))

	# We obtain the new marginals

	mPrediction <- pStar %*% gammaNew 
	vPrediction <- dStar + (pStar %*% t(Rnew))^2 %*% rep(1, gFITCinfo$m)
	
	labels <- sign(mPrediction)
	pnorm(mPrediction / sqrt(vPrediction + 1))
}

##
# This function computes the gradients of the ML approximation provided by EP once it has converged
#

computeGrads <- function(gFITCinfo, l, sigma0, sigma, tauTilde, muTilde) {

	# We compute first the representation of M = (K + PI^-1)^-1 - (PI^-1 + K)^-1 PI^-1 eta1 eta1^T PI^-1 (PI^-1 + K)^-1
	# and (K + PI^-1)^-1 = Da - PaRatRaPat

	# We use the chain rule of matrix derivatives which is the trace of (M * dKdparam)

	Da <- 1 / (gFITCinfo$D + tauTilde^-1) 
	Pa <- matrix(Da, gFITCinfo$n, gFITCinfo$m) * gFITCinfo$PRt
	Ra <- cholInverse(diag(gFITCinfo$m) + t(gFITCinfo$PRt) %*% Pa)
	PaRat <- Pa %*% t(Ra)
	RtRP <- t(gFITCinfo$PRt %*% gFITCinfo$R)

	upsilon <- Da * muTilde / tauTilde - PaRat %*% (t.default(PaRat) %*% (muTilde / tauTilde))

	diagM <- Da - rowSums(PaRat^2) - upsilon^2
	RtRPM <- matrix(Da, gFITCinfo$m, gFITCinfo$n, byrow = TRUE) * RtRP - (RtRP %*% PaRat) %*% t(PaRat) - (RtRP %*% upsilon) %*% t(upsilon)
	RtRPMPtRRt <- RtRPM %*% t(RtRP)
	RtRPdiagM <- RtRP * matrix(diagM, gFITCinfo$m, gFITCinfo$n, byrow = TRUE)
	RtRPdiagMPtRRt <- RtRPdiagM %*% t(RtRP)

	# We compute the derivatives of the kernel with respect to log_sigma

	dKnn_dlog_sigma0 <- rep(sigma0, gFITCinfo$n)
	dKmm_dlog_sigma0 <- diag(gFITCinfo$m) * sigma0
	dP_dlog_sigma0 <- matrix(0, gFITCinfo$n, gFITCinfo$m)

	gr_log_sigma0 <- -0.5 * sum(diagM * dKnn_dlog_sigma0) + sum(RtRPdiagM * t(dP_dlog_sigma0)) - 
		0.5 * sum(RtRPdiagMPtRRt * dKmm_dlog_sigma0) - sum(RtRPM * t(dP_dlog_sigma0)) + 0.5 * sum(RtRPMPtRRt * dKmm_dlog_sigma0)

	# We compute the derivatives of the kernel with respect to log_sigma0

	dKnn_dlog_sigma <- rep(sigma, gFITCinfo$n)
	dKmm_dlog_sigma <- gFITCinfo$Kmm - diag(rep(gFITCinfo$sigma0, gFITCinfo$m)) - diag(1e-10, gFITCinfo$m)
	dP_dlog_sigma <- gFITCinfo$P 

	gr_log_sigma <- -0.5 * sum(diagM * dKnn_dlog_sigma) + sum(RtRPdiagM * t(dP_dlog_sigma)) - 
		0.5 * sum(RtRPdiagMPtRRt * dKmm_dlog_sigma) - sum(RtRPM * t(dP_dlog_sigma)) + 0.5 * sum(RtRPMPtRRt * dKmm_dlog_sigma)

	# We compute the derivatives of the kernel with respect to l

	gr_log_l <- rep(0, length(l))

#	for (i in 1 : length(l)) {
#
#		dKnn_dlog_l <- rep(0, gFITCinfo$n)
#
#		distance <- as.matrix(dist(gFITCinfo$Xbar[, i, drop = FALSE ]))^2
#		dKmm_dlog_l <- gFITCinfo$Kmm * 0.5 * distance / l[ i ]
#
#		Q <- matrix(gFITCinfo$X[ , i ]^2, gFITCinfo$n, gFITCinfo$m)
#		Qbar <- matrix(gFITCinfo$Xbar[ , i ]^2, gFITCinfo$n, gFITCinfo$m, byrow = T)
#		distance <- Qbar + Q - 2 * gFITCinfo$X[ , i ] %*% t(gFITCinfo$Xbar[ , i ])
#
#                dP_dlog_l <- gFITCinfo$P * 0.5 * distance / l[ i ]

##		gr_log_l[ i ] <- -0.5 * sum(diagM * dKnn_dlog_l) + sum(RtRPdiagM * t(dP_dlog_l)) - 
##			0.5 * sum(RtRPdiagMPtRRt * dKmm_dlog_l) - sum(RtRPM * t(dP_dlog_l)) + 0.5 * sum(RtRPMPtRRt * dKmm_dlog_l)

#		gr_log_l[ i ] <- sum(RtRPdiagM * t(dP_dlog_l)) - 0.5 * sum(RtRPdiagMPtRRt * dKmm_dlog_l) - 
#			sum(RtRPM * t(dP_dlog_l)) + 0.5 * sum(RtRPMPtRRt * dKmm_dlog_l)
#	}

	Ml <- 0.5 * (t(RtRPdiagM) - t(RtRPM)) * gFITCinfo$P
	Xbarl <-  (gFITCinfo$Xbar / matrix(sqrt(l), nrow(gFITCinfo$Xbar), ncol(gFITCinfo$Xbar), byrow = TRUE))
	Xl <-  (gFITCinfo$X / matrix(sqrt(l), nrow(gFITCinfo$X), ncol(gFITCinfo$X), byrow = TRUE))
	Ml2 <- (-0.5 * RtRPdiagMPtRRt + 0.5 * RtRPMPtRRt) * gFITCinfo$Kmm * 0.5
	gr_log_l <- colSums(t(Ml) %*% Xl^2) - 2  * colSums(Xl * (Ml %*% Xbarl)) +  colSums(Ml %*% Xbarl^2) +
		colSums(t(Ml2) %*% Xbarl^2) - 2 * colSums(Xbarl * (Ml2 %*% Xbarl)) + colSums(Ml2 %*% Xbarl^2)

	gr_xbar <- matrix(0, gFITCinfo$m, length(l)) 

#	for (i in 1 : length(l)) {
#
#		distance <- matrix(gFITCinfo$X[ , i ], gFITCinfo$n, gFITCinfo$m) - matrix(gFITCinfo$Xbar[ , i ], 
#			gFITCinfo$n, gFITCinfo$m, byrow = T)
#		dP_dXbar <- gFITCinfo$P * distance / gFITCinfo$l[ i ]
#
#		distance <- (matrix(gFITCinfo$Xbar[ , i ], gFITCinfo$m, gFITCinfo$m) - matrix(gFITCinfo$Xbar[ , i ],
#			gFITCinfo$m, gFITCinfo$m, byrow = T))
#		dKmm_dXbar <- - 2 * (gFITCinfo$Kmm - diag(gFITCinfo$sigma0, gFITCinfo$m) - diag(1e-10, gFITCinfo$m)) * distance / gFITCinfo$l[ i ]
#
#		dKnn_dXbar <- rep(0, gFITCinfo$n)
#
##		gr_xbar[ ,i ] <- -0.5 * rep(sum(diagM * dKnn_dXbar), gFITCinfo$m) + rowSums(RtRPdiagM * t(dP_dXbar)) - 
##			0.5 * rowSums(RtRPdiagMPtRRt * dKmm_dXbar) - rowSums(RtRPM * t(dP_dXbar)) + 0.5 * rowSums(RtRPMPtRRt * dKmm_dXbar)
#
#		gr_xbar[ ,i ] <- rowSums(RtRPdiagM * t(dP_dXbar)) - 0.5 * rowSums(RtRPdiagMPtRRt * dKmm_dXbar) - 
#			rowSums(RtRPM * t(dP_dXbar)) + 0.5 * rowSums(RtRPMPtRRt * dKmm_dXbar)
#	}

	Xbar <- (gFITCinfo$Xbar / matrix(l, nrow(gFITCinfo$Xbar), ncol(gFITCinfo$Xbar), byrow = TRUE))
        X <- (gFITCinfo$X / matrix(l, nrow(gFITCinfo$X), ncol(gFITCinfo$X), byrow = TRUE))
	M <- - 0.5 * ((RtRPdiagMPtRRt - RtRPMPtRRt) * - 2 * (gFITCinfo$Kmm - diag(gFITCinfo$sigma0, gFITCinfo$m) - diag(1e-10, gFITCinfo$m)))
	P <- (t(RtRPdiagM) - t(RtRPM)) * gFITCinfo$P
	gr_xbar <- (Xbar * matrix(rep(1, gFITCinfo$m) %*% M, gFITCinfo$m, length(l))) - M %*% Xbar + t(P) %*% X - 
		(Xbar * matrix(rep(1, gFITCinfo$n) %*% P, gFITCinfo$m, length(l)))

	list(gr_log_l = gr_log_l, gr_log_sigma0 = gr_log_sigma0, gr_log_sigma = gr_log_sigma, gr_xbar = gr_xbar)
}

##
# This function runs EP until convergence
#

epGPCInternal <- function(X, Xbar, Y, log_l, log_sigma0, log_sigma, start = NULL, damping = 0.5) {

	l <- exp(log_l)
	sigma0 <- exp(log_sigma0)
	sigma <- exp(log_sigma)

	n <- nrow(X)
	f1Hat <- list(eta1 = rep(0, n), eta2 = rep(0, n))

	gFITCinfo <- initialize_kernel_FITC(X, Xbar, sigma, sigma0, l)

	# We check for an initial solution
	
	if (!is.null(start)) 
		f1Hat <- start$f1Hat

	# Main loop of EP

	i <- 1
	damping <- .5
	convergence <- FALSE

	while (!convergence && i < 1e3) {

		f1HatOld <- f1Hat

		# We get the marginals of the posterior approximation

		posterior <- computeTitledDistribution(gFITCinfo, f1Hat)

		meanMarginals <- posterior$mNew
		varMarginals <- posterior$vNew

		# We refine the first approximate factor in parallel

		vOld <- (varMarginals^-1 - f1Hat$eta2)^-1
		mOld <- vOld * (meanMarginals  / varMarginals - f1Hat$eta1)

		indx <- which(vOld > 0)
		vOld <- vOld[ indx ]
		mOld <- mOld[ indx ]

		logZ <- pnorm(Y * mOld / sqrt(vOld + 1), log.p = T)
		ratio <- exp(-logZ + dnorm(mOld / sqrt(vOld + 1), log = T))
		alpha <- ratio * Y / sqrt(vOld + 1)
		beta <- -ratio * (Y * mOld / sqrt(vOld + 1) + ratio) / (vOld + 1)

		eta2HatNew <- -beta / (1 + beta * vOld)
		eta1HatNew <- (alpha - mOld * beta) / (1 + beta * vOld)

		f1Hat$eta2[ indx ] <- damping * eta2HatNew + (1 - damping) * f1Hat$eta2[ indx ]
		f1Hat$eta1[ indx ] <- damping * eta1HatNew + (1 - damping) * f1Hat$eta1[ indx ]

		# We check for convergence

		change <- max(abs(f1HatOld$eta1 - f1Hat$eta1))
		change <- max(change, abs(f1HatOld$eta2 - f1Hat$eta2))

		if (change < 1e-3)
			convergence <- T
		
		evidence <- computeEvidence(gFITCinfo, f1Hat, Y)

		cat("\tIteration",  i, change, "Evidence:", evidence, "\n")

		if (REPORT == TRUE) {

			t_before <- proc.time()
			ret <- 	list(f1Hat = f1Hat, gFITCinfo = gFITCinfo)
			prediction <- predict(Xtest, ret)
			ll <- mean(log(prediction * (ytest == 1) + (1 - prediction) * (ytest == -1)))
			ee <- mean(sign(prediction - 0.5) != ytest)
			t_after <- proc.time()

			t0 <<- t0 + (t_after - t_before)

			write.table(t(c(ee, ll, proc.time() - t0)), 
				file = paste("./results/time_outter_", CONT, ".txt", sep = ""), row.names = F, col.names = F, append = TRUE)
		}

		# Annealed damping scheme

#		damping <- damping * 0.99

		i <- i + 1
	}

	# We compute the evidence and its gradient

	logZ <- computeEvidence(gFITCinfo, f1Hat, Y)
	grad <- computeGrads(gFITCinfo, l, sigma0, sigma, f1Hat$eta2, f1Hat$eta1)

	list(f1Hat = f1Hat, logZ = logZ, gFITCinfo = gFITCinfo, m = meanMarginals,
		v = varMarginals, grad = grad, l = l, sigma0 = sigma0, sigma = sigma, X = X, Y = Y)
}

###
# Function which computes the EP approximation of the log evidence.
#
# @param	f1Hat		The approximation for the first factor.
# @param	gFITCinfo	The list with the problem information.
# @param	Y		The class labels.
#
# @return	logZ		The log evidence.
#

computeEvidence <- function(gFITCinfo, f1Hat, Y) {

	Dnew <- gFITCinfo$D / (1 + gFITCinfo$D * f1Hat$eta2)
	Pnew <- matrix(1 / (1 + gFITCinfo$D * f1Hat$eta2), gFITCinfo$n,
		gFITCinfo$m) * gFITCinfo$P

	Rnew <- backsolve(rot180(t(chol(rot180(diag(gFITCinfo$m) +
		t(gFITCinfo$PRt) %*% (matrix(f1Hat$eta2 / (1 + gFITCinfo$D *
		f1Hat$eta2), gFITCinfo$n, gFITCinfo$m) * gFITCinfo$PRt))))),
		gFITCinfo$R)

	aNew <- Dnew * f1Hat$eta1
	gammaNew <- t(Rnew) %*% (Rnew %*% (t(Pnew) %*% f1Hat$eta1))

	# We obtain the new marginal means

	varMarginals <- as.double(Dnew + (Pnew %*% t(Rnew))^2 %*% rep(1, gFITCinfo$m))
	meanMarginals <- as.double(aNew) + as.double(Pnew %*% gammaNew)

	vOld <- (varMarginals^-1 - f1Hat$eta2)^-1
	mOld <- vOld * (meanMarginals  / varMarginals - f1Hat$eta1)

	logZ <- pnorm(Y * mOld / sqrt(vOld + 1), log.p = T) + 0.5 * log(2 * pi * vOld) + 0.5 * mOld^2 / vOld

	logZ <- sum(logZ) - sum(0.5 * log(2 * pi * varMarginals) + 0.5 * meanMarginals^2 / varMarginals)

	logZret <- logZ + (sum(log(diag(Rnew))) - sum(log(diag(gFITCinfo$R)))) - 0.5 * sum(log(1 + f1Hat$eta2 * gFITCinfo$D)) + 
		0.5 * sum(f1Hat$eta1 * meanMarginals) 
	
	logZret
}

##
# Function which adjust the kernel parameters by gradient descent.
#
# @param	X	n x d matrix with the data points.
# @param	Y	n-dimensional vector with the class labels.
# @param	m	The number of pseudo-inputs to use.
#
# @return	ret	A list with the following elements:
#
#			a		The posterior approximation.
#			f1Hat		The approximation to the first factor.
#			f2Har		The approximation to the second factor.
#			logZ		The approximation to the log evidence.
#			gradientLogZ	The gradient of the log evidence.
#
#			optimize_flags: booleans corresponding to sigma, sigma0, l and pesudoinputs
#

epGPCExternal <- function(X, Y, n_pseudo_inputs, eps = 1e-2) {

	t0 <<- proc.time()

	log_sigma <- 0
        log_sigma0 <- log(1e-3)
        Xbar <- X[ sample(1 : nrow(X), n_pseudo_inputs), , drop = F ]
        log_l <- rep(log(estimateL(Xbar)), ncol(Xbar))

	# We initialize the gradient optimization process

	ret <- epGPCInternal(X, Xbar, Y, log_l, log_sigma0, log_sigma)
	best <- ret

	cat(0, "New evidence:", ret$logZ, "\n")

	eps <- list(sigma = eps, sigma0 = eps, l = rep(eps, length(log_l)), xbar = matrix(eps, nrow(Xbar), ncol(Xbar)))
	sign <- list(sigma = NULL, sigma0 = NULL, l = rep(NULL, length(log_l)), xbar = matrix(0, nrow(Xbar), ncol(Xbar)))

	convergence <- F
	iteration <- 1
	
	while (! convergence && iteration < 250) {

		if (! is.null(sign$sigma)) {

	                eps$sigma[ sign$sigma == sign(ret$grad$gr_log_sigma) ] <- eps$sigma[ sign$sigma == sign(ret$grad$gr_log_sigma) ] * 1.02
	                eps$sigma[ sign$sigma != sign(ret$grad$gr_log_sigma) ] <- eps$sigma[ sign$sigma != sign(ret$grad$gr_log_sigma) ] * 0.5

	                eps$sigma0[ sign$sigma0 == sign(ret$grad$gr_log_sigma0) ] <- eps$sigma0[ sign$sigma0 == sign(ret$grad$gr_log_sigma0) ] * 1.02
	                eps$sigma0[ sign$sigma0 != sign(ret$grad$gr_log_sigma0) ] <- eps$sigma0[ sign$sigma0 != sign(ret$grad$gr_log_sigma0) ] * 0.5

	                eps$l[ sign$l == sign(ret$grad$gr_log_l) ] <- eps$l[ sign$l == sign(ret$grad$gr_log_l) ] * 1.02
	                eps$l[ sign$l != sign(ret$grad$gr_log_l) ] <- eps$l[ sign$l != sign(ret$grad$gr_log_l) ] * 0.5

	                eps$xbar[ sign$xbar == sign(ret$grad$gr_xbar) ] <- eps$xbar[ sign$xbar == sign(ret$grad$gr_xbar) ] * 1.02
	                eps$xbar[ sign$xbar != sign(ret$grad$gr_xbar) ] <- eps$xbar[ sign$xbar != sign(ret$grad$gr_xbar) ] * 0.5
		}

		sign$sigma <- sign(ret$grad$gr_log_sigma)
		sign$sigma0 <- sign(ret$grad$gr_log_sigma0)
		sign$l <- sign(ret$grad$gr_log_l)
		sign$xbar <- sign(ret$grad$gr_xbar)

		log_l <- log_l + eps$l * ret$grad$gr_log_l
		log_sigma0 <- log_sigma0 + eps$sigma0 * ret$grad$gr_log_sigma0
		log_sigma <- log_sigma + eps$sigma * ret$grad$gr_log_sigma
		Xbar <- Xbar + eps$xbar * ret$grad$gr_xbar

		# We train the model using the previous solution as the starting point. If that fails (the starting point
		# is unfeasible we start from scracht)

		tryCatch( retNew <<- epGPCInternal(X, Xbar, Y, log_l, log_sigma0, log_sigma, ret) , error = function(x)  {
			tryCatch( retNew <<- epGPCInternal(X, Xbar, Y, log_l, log_sigma0, log_sigma) , 
				error = function(x)  convergence <<- TRUE)
			}
                )

		if (is.nan(retNew$logZ))
			return(ret)

		if (abs(retNew$logZ - ret$logZ) < 1e-5)
			convergence <- T

		cat(iteration, "New evidence:", retNew$logZ, "eps_l:", eps$l, "\n", "Change:", abs(retNew$logZ - ret$logZ), "\n")

		ret <- retNew

		if (ret$logZ > best$logZ)
			best <- ret

		iteration <- iteration + 1
	}

	best
}

##
# Function that estimates the initial lengthscale value

estimateL <- function (X) {

	D <- as.matrix(dist(X))
	median(D[ upper.tri(D) ])
}

##
# Function that encodes the parameters in a vector
#

encodeParameters <- function(pseudo_inputs, log_sigma, log_sigma_0, log_l) {

    weights <- c()
    c(as.vector(pseudo_inputs), log_sigma, log_sigma_0, log_l)
}

##
# Function that decodes the parameters from a vector
#
# @arg weights          The vector of weights encoding the parameters.
# @arg n_pseudo_inputs  The number of pseudo inputs.
# @arg d                The dimensionality of the data.
#

decodeParameters <- function(weights, n_pseudo_inputs, d) {

    counter <- 0
    pseudo_inputs <- matrix(weights[ (counter + 1) : (counter + d * n_pseudo_inputs) ], n_pseudo_inputs, d)
    counter <- counter + d * n_pseudo_inputs
    log_sigma <- weights[ counter + 1 ]
    log_sigma_0 <- weights[ counter + 2 ]
    log_l <- weights[ (counter + 2 + 1) : (counter + 2 + d) ]

    list(pseudo_inputs = pseudo_inputs, log_sigma = log_sigma, log_sigma_0 = log_sigma_0, log_l = log_l)
}

##
# Function which adjust the kernel parameters by gradient descent.
#
# @param	X	n x d matrix with the data points.
# @param	Y	n-dimensional vector with the class labels.
# @param	m	The number of pseudo-inputs to use.
#
# @return	ret	A list with the following elements:
#
#			a		The posterior approximation.
#			f1Hat		The approximation to the first factor.
#			f2Har		The approximation to the second factor.
#			logZ		The approximation to the log evidence.
#			gradientLogZ	The gradient of the log evidence.
#
#			optimize_flags: booleans corresponding to sigma, sigma0, l and pesudoinputs
#

epGPCExternal_LBFGS <- function(X, Y, n_pseudo_inputs, damping = 0.5, iterations = 250, kmeans = FALSE) {

        log_sigma <- 0
        log_sigma0 <- log(1e-3)

	if (kmeans == FALSE)
		Xbar <- X[ sample(1 : nrow(X), n_pseudo_inputs), , drop = F ]
	else
		Xbar <- kmeans(X, n_pseudo_inputs)$centers

        log_l <- rep(log(estimateL(Xbar)), ncol(Xbar))
	d <- ncol(X)

	t0 <<- proc.time()

	w <- encodeParameters(Xbar, log_sigma, log_sigma0, log_l) 

	f <- function(w) {
		params <- decodeParameters(w, n_pseudo_inputs, d)

		if (is.null(global_solution_EP))
			ret <- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, params$log_sigma, damping = damping)
		else
			tryCatch(
				ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
					params$log_sigma, global_solution_EP, damping = damping)
			, error = function(x)
				ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
					params$log_sigma, damping = damping))

		global_solution_EP <<- ret

		ret$logZ
	}

	df <- function(w) {
		params <- decodeParameters(w, n_pseudo_inputs, d)

		if (is.null(global_solution_EP))
			ret <- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, params$log_sigma, damping = damping)
		else
			tryCatch(
				ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
					params$log_sigma, global_solution_EP, damping = damping)
			, error = function(x)
				ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
					params$log_sigma), damping = damping)

		encodeParameters(ret$grad$gr_xbar, ret$grad$gr_log_sigma, ret$grad$gr_log_sigma0, ret$grad$gr_log_l)
	}

	bounds <- getBounds(n_pseudo_inputs, d)

	result <- optim(w, f, df, method = "L-BFGS-B", lower = bounds$lower,
		upper = bounds$upper, control = list(fnscale = -1, trace = T,
		REPORT = 1, maxit = iterations, factr = 0))$par

	params <- decodeParameters(result, n_pseudo_inputs, d)

	if (is.null(global_solution_EP))
		ret <- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, params$log_sigma, damping = damping)
	else
		tryCatch(
			ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
				params$log_sigma, global_solution_EP, damping = damping)
		, error = function(x)
			ret <<- epGPCInternal(X, params$pseudo_inputs, Y, params$log_l, params$log_sigma_0, 
				params$log_sigma, damping = damping))
	ret
}

##
# Function that produces upper and lower bounds for the encoding of the
# parameters in a vector
#

getBounds <- function(n_pseudo_inputs, d) {

    u_log_sigma <- 10
    l_log_sigma <- -10

    u_log_sigma_0 <- 10
    l_log_sigma_0 <- -10

    u_log_l <- rep(10, d)
    l_log_l <- rep(-10, d)

    u_pseudo_inputs <- matrix(Inf, n_pseudo_inputs, d)
    l_pseudo_inputs <- matrix(-Inf, n_pseudo_inputs, d)

    weights <- c()
    upper <- c(as.vector(u_pseudo_inputs), u_log_sigma, u_log_sigma_0, u_log_l)
    lower <- c(as.vector(l_pseudo_inputs), l_log_sigma, l_log_sigma_0, l_log_l)

    list(upper = upper, lower = lower)
}


