
set.seed(1)

jitter <- 1e-10

t0 <- NULL


rowSums <- function (x, na.rm = FALSE, dims = 1L) {
    if (!is.array(x) || length(dn <- dim(x)) < 2L) 
        stop("'x' must be an array of at least two dimensions")
    if (dims < 1L || dims > length(dn) - 1L) 
        stop("invalid 'dims'")
    p <- prod(dn[-(1L:dims)])
    dn <- dn[1L:dims]
    z <- if (is.complex(x)) 
        .Internal(rowSums(Re(x), prod(dn), p, na.rm)) + (0+1i) * 
            .Internal(rowSums(Im(x), prod(dn), p, na.rm))
    else .Internal(rowSums(x, prod(dn), p, na.rm))
    if (length(dn) > 1L) {
        dim(z) <- dn
        dimnames(z) <- dimnames(x)[1L:dims]
    }
    else names(z) <- dimnames(x)[[1L]]
    z
}

colSums <- function (x, na.rm = FALSE, dims = 1L) {
    if (!is.array(x) || length(dn <- dim(x)) < 2L) 
        stop("'x' must be an array of at least two dimensions")
    if (dims < 1L || dims > length(dn) - 1L) 
        stop("invalid 'dims'")
    n <- prod(dn[1L:dims])
    dn <- dn[-(1L:dims)]
    z <- if (is.complex(x)) 
        .Internal(colSums(Re(x), n, prod(dn), na.rm)) + (0+1i) * 
            .Internal(colSums(Im(x), n, prod(dn), na.rm))
    else .Internal(colSums(x, n, prod(dn), na.rm))
    if (length(dn) > 1L) {
        dim(z) <- dn
        dimnames(z) <- dimnames(x)[-(1L:dims)]
    }
    else names(z) <- dimnames(x)[[dims + 1]]
    z
}

##
# Function that computes the product of a matrix and another matrix or vector
# given the cholesky factor of the inverse of the initial matrix.
#

inverse_times <- function(chol, x) {

    backsolve(t.default(chol), forwardsolve(chol, x))
}

##
# Function that estimates the initial lengthscale value

estimateL <- function (X) {
	D <- as.matrix(dist(X))
	median(D[ upper.tri(D) ])
}

##
# This function computes the covariance matrix for the GP
#

kernel <- function(X, l, sigma0, sigma) {
        X <- X / matrix(sqrt(l), nrow(X), ncol(X), byrow = TRUE)
        distance <- as.matrix(dist(X))^2
        sigma * exp(-0.5 * distance) + diag(sigma0, nrow(X)) + diag(rep(jitter, nrow(X)))
}

##
# Function which computes the kernel matrix between the observed data and the test data
#

kernel_nm <- function(X, Xnew, l, sigma) {

        X <- X / matrix(sqrt(l), nrow(X), ncol(X), byrow = TRUE)
        Xnew <- Xnew / matrix(sqrt(l), nrow(Xnew), ncol(Xnew), byrow = TRUE)
        n <- nrow(X)
        m <- nrow(Xnew)
        Q <- matrix(apply(X^2, 1, sum), n, m)
        Qbar <- matrix(apply(Xnew^2, 1, sum), n, m, byrow = T)
        distance <- Qbar + Q - 2 * X %*% t.default(Xnew)
        sigma * exp(-0.5 * distance)
}

##
# Function that produces upper and lower bounds for the encoding of the
# parameters in a vector
#

getBounds <- function(n_pseudo_inputs, d) {

    u_log_sigma <- 10
    l_log_sigma <- -10

    u_log_sigma_0 <- 10
    l_log_sigma_0 <- -10

    u_log_l <- rep(10, d)
    l_log_l <- rep(-10, d)

    u_m <- rep(Inf, n_pseudo_inputs)
    l_m <- rep(-Inf, n_pseudo_inputs)

    u_L <- matrix(Inf, n_pseudo_inputs, n_pseudo_inputs)
    l_L <- matrix(-Inf, n_pseudo_inputs, n_pseudo_inputs)

    u_pseudo_inputs <- matrix(Inf, n_pseudo_inputs, d)
    l_pseudo_inputs <- matrix(-Inf, n_pseudo_inputs, d)

    weights <- c()
    upper <- c(u_m, as.vector(u_L[ lower.tri(u_L, diag = T) ]),
        as.vector(u_pseudo_inputs), u_log_sigma, u_log_sigma_0, u_log_l)
    lower <- c(l_m, as.vector(l_L[ lower.tri(l_L, diag = T) ]),
        as.vector(l_pseudo_inputs), l_log_sigma, l_log_sigma_0, l_log_l)

    list(upper = upper, lower = lower)
}

##
# Function that encodes the parameters in a vector
#

encodeParameters <- function(m, L, pseudo_inputs, log_sigma, log_sigma_0,
    log_l) {

    weights <- c()
    c(m, as.vector(L[ lower.tri(L, diag = T) ]), as.vector(pseudo_inputs),
        log_sigma, log_sigma_0, log_l)
}

##
# Function that decodes the parameters from a vector
#
# @arg weights          The vector of weights encoding the parameters.
# @arg n_pseudo_inputs  The number of pseudo inputs.
# @arg d                The dimensionality of the data.
#

decodeParameters <- function(weights, n_pseudo_inputs, d) {

    counter <- 0
    m <- weights[ (counter + 1) : (counter + n_pseudo_inputs) ]
    counter <- counter + n_pseudo_inputs
    L <- matrix(0, n_pseudo_inputs, n_pseudo_inputs)
    increment <- n_pseudo_inputs * (n_pseudo_inputs - 1) / 2 + n_pseudo_inputs
    L[ lower.tri(L, diag = T) ] <-
        weights[ (counter + 1) : (counter + increment) ]
    counter <- counter + increment
    pseudo_inputs <- matrix(weights[ (counter + 1) : (counter + d *
        n_pseudo_inputs) ], n_pseudo_inputs, d)
    counter <- counter + d * n_pseudo_inputs
    log_sigma <- weights[ counter + 1 ]
    log_sigma_0 <- weights[ counter + 2 ]
    log_l <- weights[ (counter + 2 + 1) : (counter + 2 + d) ]

    list(m = m, L = L, pseudo_inputs = pseudo_inputs, log_sigma = log_sigma,
        log_sigma_0 = log_sigma_0, log_l = log_l)
}

##
# Function that evaluates the variational lower bound.
#

lower_bound <- function(weights, X, y, n_pseudo_inputs, d) {

    # We obtain the parameters

    ret <- decodeParameters(weights, n_pseudo_inputs, d)
    m <- ret$m
    L <- ret$L
    pseudo_inputs <- ret$pseudo_inputs
    log_sigma <- ret$log_sigma
    log_sigma_0 <- ret$log_sigma_0
    log_l <- ret$log_l

    # We compute the kernel matrices
    
    Kmm <- kernel(pseudo_inputs, exp(log_l), exp(log_sigma_0), exp(log_sigma))
    cholKmmT <- chol(Kmm)
    cholKmm <- t.default(cholKmmT)
    KmmInv <- chol2inv(cholKmmT)
    Knm <- kernel_nm(X, pseudo_inputs, exp(log_l), exp(log_sigma))

    # We compute the KL term

    KL <- 0.5 * (sum(2 * log(diag(cholKmm))) - sum(2 * log(abs(diag(L)))) - n_pseudo_inputs + 
	sum(diag(KmmInv %*% L %*% t.default(L))) + sum(forwardsolve(cholKmm, m)^2))

    # We compute the marginal means and variances

    A <- Knm %*% KmmInv
    mu <- A %*% m
    v <- exp(log_sigma) + exp(log_sigma_0) + jitter + rowSums((A %*% L)^2 - (A %*% cholKmm)^2)

    # We compute the integrals

    n <- nrow(X)
    ret <- rep(0, n)

#    upper_limit <- mu + 10 * sqrt(v)
#    lower_limit <- mu - 10 * sqrt(v)

    n_points <- 100

    grid_cumulative <- (matrix(seq(-10, 10, length = n_points), n, n_points, byrow = TRUE) * 
		matrix(sqrt(v), n, n_points) + matrix(mu, n, n_points)) * matrix(y, n, n_points)
    grid_density <- matrix(seq(-10, 10, length = n_points), n, n_points, byrow = TRUE)

    integrand <- pnorm(grid_cumulative, log.p = T) * dnorm(grid_density)

    ret <- rowSums((integrand[, -1 ] + integrand[, -ncol(integrand) ]) / 2) * (grid_density[, 2 ] - grid_density[, 1 ])
    
#    for (i in 1 : n) {
#       upper_limit <- mu[ i ] + 10 * sqrt(v[ i ])
#        lower_limit <- mu[ i ] - 10 * sqrt(v[ i ])
#        ret[ i ] <- integrate(function(x) pnorm(x * y[ i ], log.p = T) *
#            dnorm(x, mu[ i ], sqrt(v[ i ])), lower_limit, upper_limit)$value
#    }

    if (REPORT == TRUE) {

	model <- list(d = d, L = L, m = m, log_sigma = log_sigma,
	        log_sigma_0 = log_sigma_0, log_l = log_l,
	        n_pseudo_inputs = n_pseudo_inputs, pseudo_inputs = pseudo_inputs)

	t_before <- proc.time()
	prediction <- predict_SGPC(Xtest, model)
	ee <- mean(sign(prediction - 0.5) != ytest)
	ll <- mean(log(prediction * (ytest == 1) + (1 - prediction) * (ytest == -1)))
	t_after <- proc.time()

	t0 <- t0 + (t_after - t_before)
		
	write.table(t.default(c(ee, ll, proc.time() - t0)), 
		file = paste("./results/time_outter_", CONT, ".txt", sep = ""), row.names = F, col.names = F, append = TRUE)
    }

    sum(ret) - KL
}

##
# Function that computes the gradientes of the variational lower bound.
#

grad_lower_bound <- function(weights, X, y, n_pseudo_inputs, d) {

    # We obtain the parameters

    ret <- decodeParameters(weights, n_pseudo_inputs, d)
    m <- ret$m
    L <- ret$L
    pseudo_inputs <- ret$pseudo_inputs
    log_sigma <- ret$log_sigma
    log_sigma_0 <- ret$log_sigma_0
    log_l <- ret$log_l

    # We compute the kernel matrices
    
    Kmm <- kernel(pseudo_inputs, exp(log_l), exp(log_sigma_0), exp(log_sigma))
    cholKmmT <- chol(Kmm)
    cholKmm <- t.default(cholKmmT)
    KmmInv <- chol2inv(chol(Kmm))
    Knm <- kernel_nm(X, pseudo_inputs, exp(log_l), exp(log_sigma))

    # We compute the gradient of KL with respect to m, L and Kmm

    dKLdm <- KmmInv %*% m
    KmmInvL <- KmmInv %*% L
    dKLdKmm <- 0.5 * (KmmInv - KmmInvL %*% t.default(KmmInvL) - dKLdm %*% t.default(dKLdm))
    
    dKLdS <- 0.5 * (KmmInv - chol2inv(t.default(L)))
    dKLdL <- 2 * dKLdS %*% L

    # We compute the marginal means and variances

    A <- Knm %*% KmmInv
    mu <- A %*% m
    AL <- A %*% L
    AcholKmm <- A %*% cholKmm
    v <- exp(log_sigma) + exp(log_sigma_0) + jitter + rowSums(AL^2 - AcholKmm^2)

    # We compute the gradient of the expectations with respect to the marginal
    # means and variances

    n <- nrow(X)

    n_points <- 100

        ratio <- function(x) {
            z <- exp(dnorm(x, log = T) - pnorm(x, log.p = T))
#            z[ x < -30 ] <- -x[ x < -30 ] - 1 / x[ x < -30 ] + 2 / x[ x < -30 ]^3
            z
        }


    grid_cumulative <- (matrix(seq(-10, 10, length = n_points), n, n_points, byrow = TRUE) * 
		matrix(sqrt(v), n, n_points) + matrix(mu, n, n_points)) * matrix(y, n, n_points)
    grid_density <- matrix(seq(-10, 10, length = n_points), n, n_points, byrow = TRUE)

    integrand <- ratio(grid_cumulative) * matrix(y, n, n_points) * dnorm(grid_density)
    dExpdmu <- rowSums((integrand[, -1 ] + integrand[, -ncol(integrand) ]) / 2) * (grid_density[, 2 ] - grid_density[, 1 ])

    integrand <- 0.5 * -ratio(grid_cumulative) * (grid_cumulative + ratio(grid_cumulative)) * dnorm(grid_density)
    dExpdv <- rowSums((integrand[, -1 ] + integrand[, -ncol(integrand) ]) / 2) * (grid_density[, 2 ] - grid_density[, 1 ])
 
#    dExpdmu <- rep(0, n)
#    dExpdv <- rep(0, n)
#    for (i in 1 : n) {
#        upper_limit <- mu[ i ] + 10 * sqrt(v[ i ])
#        lower_limit <- mu[ i ] - 10 * sqrt(v[ i ])
#
#        ratio <- function(x) {
#            x <- x * y[ i ]
#            z <- exp(dnorm(x, log = T) - pnorm(x, log.p = T))
#            z[ x < -30 ] <- -x[ x < -30 ] - 1 / x[ x < -30 ] +
#                2 / x[ x < -30 ]^3
#            z
#        }
#
#        dExpdmu[ i ] <- integrate(function(x) ratio(x) * y[ i ] * dnorm(x,
#            mu[ i ], sqrt(v[ i ])), lower_limit, upper_limit)$value
#        dExpdv[ i ] <- 0.5 * integrate(function(x) -ratio(x) * (x * y[ i ] + ratio(x)) *
#             dnorm(x, mu[ i ], sqrt(v[ i ])), lower_limit, upper_limit)$value
#    }

    # We compute the gradients of the expecatations with respect to m, L, Kmm,
    # Knm and kii

    dmudm <- t.default(A)
    aux_m <- matrix(dExpdmu, n_pseudo_inputs, n, byrow = T) * dmudm
    aux_v <- matrix(dExpdv, n_pseudo_inputs, n, byrow = T) * dmudm
    dExpdm <- rowSums(aux_m)
    dExpdS <- aux_v %*% t.default(dmudm)
    dExpdL <- 2 * dExpdS %*% L
    dExpdmudmudKmm <- (matrix(-aux_m %*% rep(1, n), n_pseudo_inputs,n_pseudo_inputs) * t.default(matrix(dKLdm, n_pseudo_inputs, n_pseudo_inputs,)))
    dExpdvdvdKmm <- - (2 * KmmInvL %*% t.default(KmmInvL)  - KmmInv) %*% t.default(aux_v %*% Knm)
    dExpdKmm <- dExpdmudmudKmm + dExpdvdvdKmm

    dExpdkii <- sum(dExpdv)
    dExpdvdvdKnm <- 2 * t.default((KmmInvL %*% t.default(L)) %*% aux_v - aux_v)

    dExpdmudmudKnm <- matrix(dKLdm, n, n_pseudo_inputs, byrow = T) * matrix(dExpdmu, n, n_pseudo_inputs)

    dExpdKnm <- dExpdmudmudKnm + dExpdvdvdKnm

    # We compute the gradient with respect to m and L

    grad_m <- dExpdm - dKLdm
    grad_L <- dExpdL - dKLdL
    
    # We compute the gradient with respect to log_sigma

    dKmmdlog_sigma <- Kmm - diag(exp(log_sigma_0) + jitter, n_pseudo_inputs)
    dKnmdlog_sigma <- Knm 
    dkiidlog_sigma <- exp(log_sigma)

    grad_log_sigma <- sum(dExpdKmm * dKmmdlog_sigma) + sum(dExpdKnm * dKnmdlog_sigma) + dExpdkii * dkiidlog_sigma - sum(dKLdKmm * dKmmdlog_sigma)

    # We compute the gradients with respect to log_sigma_0

    dKmmdlog_sigma_0 <- diag(n_pseudo_inputs) * exp(log_sigma_0)
    dkiidlog_sigma_0 <- exp(log_sigma_0)
    grad_log_sigma_0 <- sum(dExpdKmm * dKmmdlog_sigma_0) +
        dExpdkii * dkiidlog_sigma_0 - sum(dKLdKmm * dKmmdlog_sigma_0)

    # We compute the gradient with respect to log_l

    grad_log_l <- rep(0, d)
    Kmm_no_diagonal <- (Kmm - diag(exp(log_sigma_0) + jitter, n_pseudo_inputs))

#    for (i in 1 : d) {
#       distance <- as.matrix(dist(pseudo_inputs[ , i, drop = FALSE ]))^2
#        dKmmdlog_l <- Kmm_no_diagonal * 0.5 * distance * exp(-log_l[ i ])
#        Q <- matrix(X[ , i ]^2, n, n_pseudo_inputs)
#        Qbar <- matrix(pseudo_inputs[ , i ]^2, n, n_pseudo_inputs, byrow = T)
#        distance <- Qbar + Q - 2 * X[ , i ] %*% t(pseudo_inputs[ , i ])
#        dKnmdlog_l <- Knm * 0.5 * distance * exp(-log_l[ i ])
#        grad_log_l[ i ] <- sum(dExpdKmm * dKmmdlog_l) +
#            sum(dExpdKnm * dKnmdlog_l) - sum(dKLdKmm * dKmmdlog_l)
#    }

    Ml2 <- (dExpdKmm - dKLdKmm) * 0.5 * Kmm_no_diagonal 
    Ml <-  dExpdKnm * Knm * 0.5
    Xbarl <-  (pseudo_inputs / matrix(sqrt(exp(log_l)), nrow(pseudo_inputs), ncol(pseudo_inputs), byrow = TRUE))
    Xl <-  (X / matrix(sqrt(exp(log_l)), nrow(X), ncol(X), byrow = TRUE))
    grad_log_l <- colSums(t(Ml) %*% Xl^2) - 2  * colSums(Xl * (Ml %*% Xbarl)) +  colSums(Ml %*% Xbarl^2) +
                colSums(t(Ml2) %*% Xbarl^2) - 2 * colSums(Xbarl * (Ml2 %*% Xbarl)) + colSums(Ml2 %*% Xbarl^2)

    # We compute the gradient with respec to the pseudo-inputs

    grad_pseudo_inputs <- matrix(0, n_pseudo_inputs, d)
#    for (i in 1 : d) {
#       distance <- matrix(pseudo_inputs[ , i ], n_pseudo_inputs, n_pseudo_inputs) -
#            matrix(pseudo_inputs[ , i ], n_pseudo_inputs, n_pseudo_inputs, byrow = T)
#        dKmmd_pseudo_input <- Kmm_no_diagonal * distance / exp(log_l[ i ])
#        distance <- matrix(X[ , i ], n, n_pseudo_inputs) -
#            matrix(pseudo_inputs[ , i ], n, n_pseudo_inputs, byrow = T)
#        dKnmd_pseudo_input <- Knm * distance / exp(log_l[ i ])
#
#        grad_pseudo_inputs[ , i ] <- colSums(dExpdKmm * dKmmd_pseudo_input) -
#            rowSums(dExpdKmm * dKmmd_pseudo_input) +
#            colSums(dExpdKnm * dKnmd_pseudo_input) - 
#            colSums(dKLdKmm * dKmmd_pseudo_input) +
#            rowSums(dKLdKmm * dKmmd_pseudo_input)
#    }

    Xbar <- (pseudo_inputs / matrix(exp(log_l), nrow(pseudo_inputs), ncol(pseudo_inputs), byrow = TRUE))
    X <- (X / matrix(exp(log_l), nrow(X), ncol(X), byrow = TRUE))
    Mbar <- - (dExpdKmm - dKLdKmm) * Kmm_no_diagonal
    Mbar2 <- dExpdKnm * Knm
    grad_pseudo_inputs <- (Xbar * matrix(rep(1, nrow(pseudo_inputs)) %*% Mbar, nrow(pseudo_inputs), length(log_l)) - t.default(Mbar) %*% Xbar) +
	(Xbar * matrix(rep(1, nrow(pseudo_inputs)) %*% t.default(Mbar), nrow(pseudo_inputs), length(log_l)) - Mbar %*% Xbar)  +
	(t.default(Mbar2) %*% X) - ((Xbar * matrix(rep(1, nrow(X)) %*% Mbar2, nrow(pseudo_inputs), length(log_l))))

    encodeParameters(grad_m, grad_L, grad_pseudo_inputs, grad_log_sigma, grad_log_sigma_0, grad_log_l)
}

##
# Function that fits the sparse GP classifier
#

fit_SGPC <- function(Xtrain, ytrain, n_pseudo_inputs, kmeans = FALSE, iterations = 250) {

    t0 <<- proc.time()

    n <- nrow(Xtrain)
    d <- ncol(Xtrain)

    # We fix the initial parameters

    log_sigma <- 0
    log_sigma_0 <- log(1e-3)


    if (kmeans == FALSE)
	pseudo_inputs <- Xtrain[ sample(1 : n, n_pseudo_inputs), , drop = F ]
    else
	pseudo_inputs <- kmeans(Xtrain, n_pseudo_inputs)$centers

    log_l <- rep(log(estimateL(pseudo_inputs)), ncol(pseudo_inputs))
    Kmm <- kernel(pseudo_inputs, exp(log_l), exp(log_sigma_0), exp(log_sigma))

    L <- t.default(chol(Kmm))
    m <- rep(0, n_pseudo_inputs)
    w <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0, log_l)

    # We optimize the objective function

    bounds <- getBounds(n_pseudo_inputs, d)
    result <- optim(w, lower_bound, grad_lower_bound, Xtrain, ytrain,
        n_pseudo_inputs, d, method = "L-BFGS-B", lower = bounds$lower,
        upper = bounds$upper, control = list(fnscale = -1, trace = T,
        REPORT = 1, maxit = iterations, factr = 0))

    w <- result$par

    ret <- decodeParameters(w, n_pseudo_inputs, d)

    list(d = d, L = ret$L, m = ret$m, log_sigma = ret$log_sigma,
        log_sigma_0 = ret$log_sigma_0, log_l = ret$log_l,
        n_pseudo_inputs = n_pseudo_inputs, pseudo_inputs = ret$pseudo_inputs)
}


##
# Function that fits the sparse GP classifier
#

fit_SGPC_GD <- function(Xtrain, ytrain, n_pseudo_inputs, eps = 1e-2) {

    t0 <<- proc.time()

    n <- nrow(Xtrain)
    d <- ncol(Xtrain)

    # We fix the initial parameters

    log_sigma <- 0
    log_sigma_0 <- log(1e-3)
    pseudo_inputs <- Xtrain[ sample(1 : n, n_pseudo_inputs), , drop = F ]
    log_l <- rep(log(estimateL(pseudo_inputs)), ncol(pseudo_inputs))
    Kmm <- kernel(pseudo_inputs, exp(log_l), exp(log_sigma_0), exp(log_sigma))

    L <- t.default(chol(Kmm))
    m <- rep(0, n_pseudo_inputs)
    w <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0, log_l)

    # We optimize the objective function

    bounds <- getBounds(n_pseudo_inputs, d)

    eps <- rep(eps, length(w))
    sign <- NULL
    best_value <- -Inf
    best <- NULL
    failed <- FALSE
    i <- 1


    while(i < 250 && failed != TRUE) {

	tryCatch({
		grad <- grad_lower_bound(w, Xtrain, ytrain, n_pseudo_inputs, d)
	
		if (! is.null(sign)) {
			eps[ sign(grad) != sign ] <- eps[ sign(grad) != sign ] * 0.5
			eps[ sign(grad) == sign ] <- eps[ sign(grad) == sign ] * 1.02
		}
	
		sign <- sign(grad)
		w <- w + eps * grad
	
		value <- lower_bound(w, Xtrain, ytrain, n_pseudo_inputs, d)
		cat(i, value, "\n")
	
		if (value > best_value) {
			best <- w	
			best_value <- value
		}	



		
		i <- i +1
	}, error = function(x) failed <<- TRUE)
    }

    ret <- decodeParameters(best, n_pseudo_inputs, d)

    list(d = d, L = ret$L, m = ret$m, log_sigma = ret$log_sigma,
        log_sigma_0 = ret$log_sigma_0, log_l = ret$log_l,
        n_pseudo_inputs = n_pseudo_inputs, pseudo_inputs = ret$pseudo_inputs)
}



##
# Function that makes predictions given 

predict_SGPC <- function(Xtest, spgpc) {

    d <- spgpc$d
    L <- spgpc$L
    m <- spgpc$m
    log_sigma <- spgpc$log_sigma
    log_sigma_0 <- spgpc$log_sigma_0
    log_l <- spgpc$log_l
    n_pseudo_inputs <- spgpc$n_pseudo_inputs
    pseudo_inputs <- spgpc$pseudo_inputs
   
    # We compute the kernel matrices

    Kmm <- kernel(pseudo_inputs, exp(log_l), exp(log_sigma_0), exp(log_sigma))
    cholKmmT <- chol(Kmm)
    cholKmm <- t.default(cholKmmT)
    Knm <- kernel_nm(Xtest, pseudo_inputs, exp(log_l), exp(log_sigma))

    # We compute the marginal means and variances

    A <- Knm %*% chol2inv(cholKmmT)

    mu <- A %*% m
    v <- exp(log_sigma) + exp(log_sigma_0) + jitter + rowSums((A %*% L)^2 - (A %*% cholKmm)^2)

    # We compute the class probabilities

    pnorm(mu / sqrt(v + 1))
}

##
# Function to test the gradients
#

test_gradients <- function(problemInfo = NULL) {

    # We check if there is any problem info available

    if (!is.null(problemInfo)) {

        X <- problemInfo$Xtrain
        y <- problemInfo$ytrain
        n_pseudo_inputs <- problemInfo$n_pseudo_inputs

        n <- nrow(Xtrain)
        d <- ncol(Xtrain)

        log_sigma <- rnorm(1)
        log_sigma_0 <- rnorm(1)
        log_l <- rnorm(d)
        pseudo_inputs <- X[ sample(1 : n, n_pseudo_inputs), , drop = F ]
        m <- rnorm(n_pseudo_inputs)
        L <- matrix(rnorm(n_pseudo_inputs^2), n_pseudo_inputs, n_pseudo_inputs)
        L <- t.default(chol(L %*% t.default(L)))

    } else {

        # Generate some synthetic data

        n <- 10
        d <- 5
        X <- matrix(rnorm(n * d), n , d)
        w <- rnorm(d)
        y <- sign(X %*% w)
        log_sigma <- rnorm(1)
        log_sigma_0 <- rnorm(1) - 2
        log_l <- rnorm(d)

        n_pseudo_inputs <- 2
        m <- rnorm(n_pseudo_inputs)
        pseudo_inputs <- X[ sample(1 : n, n_pseudo_inputs), , drop = F ]
        L <- matrix(rnorm(n_pseudo_inputs^2), n_pseudo_inputs, n_pseudo_inputs)
        L <- t.default(chol(L %*% t.default(L)))

    }

    # We encode parameters, decode and evaluate the lower_bound

    weights <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0, log_l)
    ret <- decodeParameters(weights, n_pseudo_inputs, d)
    ret <- lower_bound(weights, X, y, n_pseudo_inputs, d)

    # We test the gradient as a function of m

    error <- F
    for (i in 1 : length(m)) {
        mH <- m
        mH[ i ] <- mH[ i ] + 1e-6
        mL <- m
        mL[ i ] <- mL[ i ] - 1e-6
        weightsH <- encodeParameters(mH, L, pseudo_inputs, log_sigma, log_sigma_0, log_l)
        weightsL <- encodeParameters(mL, L, pseudo_inputs, log_sigma, log_sigma_0, log_l)
        retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
        retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

        gradient <- (retH - retL) / (2 * 1e-6)

        ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
        ret <- decodeParameters(ret, n_pseudo_inputs, d)
        gradient_computed <- ret$m

        if (abs(gradient - gradient_computed[ i ]) / abs(gradient + 1e-10) > 1e-3) {
            cat("Error in gradient of m!\n")
            error <- T
        }
    }

    # We test the gradient as a function of L

    for (i in 1 : n_pseudo_inputs) {
        for (j in i : n_pseudo_inputs) {

            LH <- L
            LH[ i, j ] <- LH[ i, j ] + 1e-6
            LL <- L
            LL[ i, j ] <- LL[ i, j ] - 1e-6
            weightsH <- encodeParameters(m, LH, pseudo_inputs, log_sigma,
                log_sigma_0, log_l)
            weightsL <- encodeParameters(m, LL, pseudo_inputs, log_sigma,
                log_sigma_0, log_l)
            retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
            retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

            gradient <- (retH - retL) / (2 * 1e-6)

            ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
            ret <- decodeParameters(ret, n_pseudo_inputs, d)
            gradient_computed <- ret$L

            if (abs(gradient - gradient_computed[ i, j ]) / abs(gradient + 1e-10) > 1e-3) {
                cat("Error in gradient of L!\n")
                error <- T
            }
        }
    }

    # We test the gradient as a function of log_sigma

    log_sigmaH <- log_sigma + 1e-6
    log_sigmaL <- log_sigma - 1e-6

    weightsH <- encodeParameters(m, L, pseudo_inputs, log_sigmaH, log_sigma_0,
        log_l)
    weightsL <- encodeParameters(m, L, pseudo_inputs, log_sigmaL, log_sigma_0,
        log_l)
    retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
    retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

    gradient <- (retH - retL) / (2 * 1e-6)

    ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
    ret <- decodeParameters(ret, n_pseudo_inputs, d)
    gradient_computed <- ret$log_sigma

    if (abs(gradient - gradient_computed) / abs(gradient + 1e-10) > 1e-3) {
        cat("Error in gradient of log_sigma!\n")
        error <- T
    }

    # We test the gradient as a function of log_sigma_0

    log_sigma_0H <- log_sigma_0 + 1e-6
    log_sigma_0L <- log_sigma_0 - 1e-6

    weightsH <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0H,
        log_l)
    weightsL <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0L,
        log_l)
    retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
    retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

    gradient <- (retH - retL) / (2 * 1e-6)

    ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
    ret <- decodeParameters(ret, n_pseudo_inputs, d)
    gradient_computed <- ret$log_sigma_0

    if (abs(gradient - gradient_computed) / abs(gradient + 1e-10) > 1e-3) {
        cat("Error in gradient of log_sigma_0!\n")
        error <- T
    }

    # We test the gradient as a function of log_l

    for (i in 1 : d) {

        log_lH <- log_l
        log_lH[ i ] <- log_l[ i ] + 1e-6
        log_lL <- log_l
        log_lL[ i ] <- log_l[ i ] - 1e-6

        weightsH <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0,
            log_lH)
        weightsL <- encodeParameters(m, L, pseudo_inputs, log_sigma, log_sigma_0,
            log_lL)
        retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
        retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

        gradient <- (retH - retL) / (2 * 1e-6)

        ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
        ret <- decodeParameters(ret, n_pseudo_inputs, d)
        gradient_computed <- ret$log_l

        if (abs(gradient - gradient_computed[ i ]) / abs(gradient + 1e-10) > 1e-3) {
            cat("Error in gradient of log_l!\n")
            error <- T
        }
    }

    # We test the gradient as a function of the pseudo_inputs

    for (i in 1 : n_pseudo_inputs) {
        for (j in 1 : d) {

            pseudo_inputsH <- pseudo_inputs
            pseudo_inputsH[ i, j ] <- pseudo_inputsH[ i, j ] + 1e-6
            pseudo_inputsL <- pseudo_inputs
            pseudo_inputsL[ i, j ] <- pseudo_inputsL[ i, j ] - 1e-6

            weightsH <- encodeParameters(m, L, pseudo_inputsH, log_sigma,
                log_sigma_0, log_l)
            weightsL <- encodeParameters(m, L, pseudo_inputsL, log_sigma,
                log_sigma_0, log_l)
            retH <- lower_bound(weightsH, X, y, n_pseudo_inputs, d)
            retL <- lower_bound(weightsL, X, y, n_pseudo_inputs, d)

            gradient <- (retH - retL) / (2 * 1e-6)

            ret <- grad_lower_bound(weights, X, y, n_pseudo_inputs, d)
            ret <- decodeParameters(ret, n_pseudo_inputs, d)
            gradient_computed <- ret$pseudo_inputs

            if (abs(gradient - gradient_computed[ i, j ]) / abs(gradient + 1e-10) > 1e-3) {
                cat("Error in gradient of pseudo_inputs!\n")
                error <- T
            }
        }
    }

    if (error)
        cat("Errors during the computation of the gradients!\n")
    else
        cat("Gradient computation correct!\n")
}

# We test the gradients

#test_gradients()
