cov.from.normscores <- function(Y) {
  # This subroutine computes the empirical covariance matrix based on ranks
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     Y : (generated) data, i.e. samples from N(0,cov)
  #
  # RETURNS:
  #     S : (p+q)x(p+q) matrix containing the covariance based on the ranks 

  Ranks <- apply(Y, 2, rank, ties.method = "random", na.last = "keep")   # Returns an array of values giving to the rank, dimensions of that matrix: obeservations x (p+q) 
  N <- apply(!is.na(Ranks), 2, sum)
  U <- t(t(Ranks) / (N + 1))
  Z <- qnorm(U)
  S <- t(Z) %*% Z
  S <- S / S[1, 1]
  return(S)
}




sigma.edge.12 <- function(Sigma, p, q) {
  # This subroutine returns the number of edges in Sigma.12
  # It is invoked from 'SampleSigma()'.
  #
  # ARGS:
  #     Sigma : Sparse covariance matrix with many hubs, entries: -1, 0, +1
  #      p, q : number of nodes in the '12' and '22' part of the covariance matrix,
  #           : i.e. p + q  is number of nodes in the network
  #
  # RETURNS:
  #     EdgesS.12 : number of edges in Sigma.12
  
  EdgesS.12 = length( which(Sigma[1:p,(p + 1):(p + q)] != 0) )
  return(EdgesS.12)
}




sigma.edge.22 <- function(Sigma, p, q) {
  # This subroutine returns the number of edges in Sigma.22
  # It is invoked from 'SampleSigma()'.
  #
  # ARGS:
  #     Sigma : Sparse covariance matrix with many hubs, entries: -1, 0, +1
  #      p, q : number of nodes in the '12' and '22' part of the covariance matrix,
  #           : i.e. p + q  is number of nodes in the network
  #
  # RETURNS:
  #     EdgesS.22 : number of edges in Sigma.22 

  n.22 = length( which(Sigma[(p + 1):(p + q),(p + 1):(p + q)] != 0) )
  n.22.diag = length( which(diag(Sigma)[(p + 1):(p + q)] != 0) )
  EdgesS.22 = (n.22 - n.22.diag)/2
  return(EdgesS.22)
}




SampleSigma <- function(p = 10, q = 90, min.edge.12 = 5, max.edge.12 = 20, min.edge.22 = 5, max.edge.22 = 20, shape.Alpha = 0.03, shape.Beta = 1) {  
  # This is a subroutine for the generation of a network with many hubs.
  # It is invoked from within the function 'SampleGaussWishart()'.
  #
  # ARGS:
  #     p, q        : number of nodes in the '12' and '22' part of the covariance matrix,
  #                 : i.e. p + q  is number of nodes in the network
  #     min.edge.12 : min./max. number of edges in the
  #     max.edge.12 : '12' part of the covariance matrix
  #     min.edge.22 : min./max. number of edges in the
  #     max.edge.22 : '22' part of the covariance matrix
  #     shape.Alpha : non-negative shape parameter Alpha for Beta distribution
  #     shape.Beta  : non-negative shape parameter Beta for Beta distribution
  #
  # RETURNS:
  #     Sigma : Sparse covariance matrix with many hubs, entries: -1, 0, +1

  Sigma <- matrix(0, nrow = p + q, ncol = p + q)
  
  while (sigma.edge.12(Sigma, p, q) < min.edge.12 | sigma.edge.12(Sigma, p, q) > max.edge.12 | sigma.edge.22(Sigma, p, q) < min.edge.22 | sigma.edge.22(Sigma, p, q) > max.edge.22) {
    Sigma <- matrix(0, nrow = p + q, ncol = p + q)
    success.prob <- rbeta(p + q, shape1 = shape.Alpha, shape2 = shape.Beta)   # Random generation of beta distributed numbers, success.prob ~ beta
    ### ??? row_i.index = seq(from = 1, to = (p + q), by = 1)
    
    for (i in 1:(p + q)) {
      hasBond <- rbinom(n = p + q, size = 1, prob = success.prob[i])   # draw [0 or +1], with n: number of observations, size: number of trials, p: probability of success on each trial
      row_i.index <- which(abs(Sigma[i, ]) < 100)   # ??? put outside for loop
      Sigma[i, row_i.index] <- hasBond[row_i.index]   # sparse square matrix with entries: 0 or +1
    }
    
    is.connected <- which(Sigma == 1, arr.ind = TRUE)   # list of entries (i,j) in Sigma that are '+1'
    perm <- sample(nrow(is.connected))   # generate permutations of the indices of those entries 
    Sigma[is.connected[perm[1:floor(nrow(is.connected)/2)], ]] <- -1   # using the permutated indices, replace +1 -> -1 in half of those entries 
    Sigma <- sign(Sigma + t(Sigma))   # make Sigma symmetric
    diag(Sigma) <- 0
  }
  
  return(Sigma)
}




sample.gauss.wishart <- function(p = 10, q = 90, min.edge.12 = 5, max.edge.12 = 20, min.edge.22 = 5, max.edge.22 = 20, f.dim = floor((p + q) * 10),
                                 gamma.shape = 2, gamma.scale = 2, do.uniform = TRUE, rescale.to.correlation = TRUE, f.d.term = 0.1) {
  # This is a subroutine for the generation of a random network, i.e. the precision matrix.
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     p, q                   : number of nodes in the '12' and '22' part of the covariance matrix,
  #                            : i.e. p + q  is number of nodes in the network
  #     min.edge.12            : min./max. number of edges in the
  #     max.edge.12            : '12' part of the covariance matrix
  #     min.edge.22            : min./max. number of edges in the
  #     max.edge.22            : '22' part of the covariance matrix  
  #     f.dim                  : degrees of freedom
  #     gamma.shape            : gamma distribution: shape parameter, must be positive
  #     gamma.scale            : gamma distribution: scale parameter, must be strictly positive
  #     do.uniform             : if TRUE, draw 'choice' from rand. uniform, else draw from rand. gamma
  #     rescale.to.correlation : if TRUE, covariance is rescales to be the correlation 
  #     f.d.term               : positive constant to ensure positive definiteness
  #
  # RETURNS:
  #     list object containing:   (i) data    : sample from N(0,cov)
  #                              (ii) cov     : covariance
  #                             (iii) inv.cov : inverse covariance

  Sigma <- SampleSigma(p = p, q = q, min.edge.12 = min.edge.12, max.edge.12 = max.edge.12, min.edge.22 = min.edge.22, max.edge.22 = max.edge.22)   # generate sparse covariance matrix with many hubs, entries: -1, 0, +1
  dimnames(Sigma)[[1]] <- 1:(p + q)   # rename rows of Sigma by the sequence 1...(p+q)
  dimnames(Sigma)[[2]] <- 1:(p + q)   # rename columns of Sigma by the sequence 1...(p+q)
  edges <- which(Sigma != 0, arr.ind = T)   # index all elements in Sigma representing a depedency between two nodes, i.e. an edge
  edges.upper <- which(edges[ ,2] > edges[ ,1])   # edges in the upper triangular part of Sigma (excluding the diagonal)
  edges <- edges[edges.upper, , drop = FALSE]   # creates a row matrix
  Inv.Cov <- Sigma
  choice <- rgamma(n = length(edges.upper), shape = gamma.shape, scale = gamma.scale)

  if (do.uniform) {   # default: TRUE
    choice <- runif(length(edges.upper), min = 0.3, max = 1)
  }
  
  Inv.Cov[edges] <- Inv.Cov[edges] * choice   # multiply entries with +1,-1 contained in the upper triangular part of Inv.Cov with the 'choice'-random numbers  
  tmp <- edges
  edges[, 2] <- edges[, 1]
  edges[, 1] <- tmp[, 2]
  Inv.Cov[edges] <- Inv.Cov[tmp]
  dimnames(Inv.Cov) <- dimnames(Sigma)
  diag(Inv.Cov) <- 0
  ev <- eigen(Inv.Cov)$values
  diag(Inv.Cov) <- abs(min(ev)) + f.d.term   # for positive definiteness
  cov <- solve(Inv.Cov)   # computer inverse of matrix
  
  if (rescale.to.correlation) {   # default: TRUE
    D <- diag(cov)   # extract the diagonal of cov
    cov <- cov/(sqrt(D) %*% t(sqrt(D)))   # covariance becomes correlation
    Inv.Cov <- Inv.Cov/(sqrt(D^(-1)) %*% t(sqrt(D^(-1))))   # adjust the inverse covariance accordingly
  }
  
  dimnames(cov) <- dimnames(Sigma)
  eig.cov <- eigen(cov)
  sqr.cov <- eig.cov$vectors %*% diag(sqrt(eig.cov$values)) %*% t(eig.cov$vectors)
  Z <- matrix(rnorm(nrow(cov) * f.dim), nrow = nrow(cov), ncol = f.dim)
  data <- sqr.cov %*% Z   # a sample from N(0,cov)
  
  return(list( data    = t(data),
               cov     = cov,
               inv.cov = Inv.Cov ))
}




MGIG <- function(df, A, B, iter = 20) {
  # This is a subroutine to sample from the MGIG distribution.
  # It is invoked from 'MarkovBlanketKDsparseOneDraw()'.
  #
  # ARGS:
  #     df   : degrees of freedom, here: 0.5 * (n + n0) + 1 with n0 = 0 by default
  #     A    : matrix, here: S.11 + W.prior
  #     B    : matrix, here: W.12 %*% S.22.lambda %*% t(W.12)
  #     iter : number of iterations
  #
  # RETURNS:
  #     list object containing:   (i) Z    : sample from MGIG: Z ~ |Z|^{df-1} etr(-1/2 (A Z + B Z^{-1}))
  #                              (ii) df   : see args
  #                             (iii) A    : see args
  #                              (iv) B    : see args
  #                               (v) iter : see args
  
  A <- as.matrix(A)
  B <- as.matrix(B)
  p <- ncol(A)
  
  if ((nrow(A) != p) | (ncol(B) != p) | (nrow(B) != p)) {
    print("wrong dimensions in MGIG")
    return
  }
  
  if (iter %% 2 != 0) {
    print("warning: iter set to iter+1")
    iter <- iter + 1
  }
  
  n <- 2 * df + p - 1
  A.inv <- solve(A)
  B.inv <- solve(B)
  Y.1 <- rWishart(1, n, A.inv)
  Y.1 <- Y.1[, , 1]
  Y.2 <- rWishart(1, n, B.inv)
  Y.2 <- Y.2[, , 1]
  Y <- list()
  Y[[1]] <- Y.1
  Y[[2]] <- Y.2
  Z <- solve(Y[[iter %% 2 + 1]])
  
  for (i in (iter - 1):1) {
    Z <- solve(Y[[i %% 2 + 1]] + Z)
    if (i %% 2 == 0) {
      Y[[1]] <- rWishart(1, n, A.inv)[, , 1]
      Y[[2]] <- rWishart(1, n, B.inv)[, , 1]
    }    
  }
  
  Z <- Z + Y[[1]]
  
  return(list( Z    = Z,
               df   = df,
               A    = A,
               B    = B,
               iter = iter ))
}






































Bayes.glasso.MB <- function(S, n, lambda, NSCAN = 1000, burnin = 300, p.1, p.2) {
  # This is the subroutine containing the Bayesian graphical lasso.
  # It is invoked from 'BGL()'.
  #
  # ARGS:
  #     S        : sample covariance 
  #     n        : number of observations
  #     lambda   : sparsity parameter > 0, higher = more penalty on number of edges
  #     NSCAN    : number of MCMC samples
  #     burnin   : number of burn-in samples
  #     p.1, p.2 : number of nodes in the '12' and '22' part of the covariance matrix,
  #              : i.e. p.1 + p.2 is number of nodes in the network
  #
  # RETURNS:
  #     list object containing:   (i) MB.arr : (NSCAN)x(p.1*p.2)
  #                              (ii) W.avg  : contains the asas, same size as matrix S

  p <- nrow(S)
  T.inv <- matrix(0, p, p)
  W <- solve(S + diag(lambda, p))
  MB.arr <- matrix(0, NSCAN, p.1 * p.2)
  W.avg <- matrix(0, nrow = p, ncol = p)
  for (nscan in 1:NSCAN) {
    for (i in 1:p) {
      ## partition
      seq.1 <- NULL
      if (i - 1 >= 1) {
        seq.1 <- 1:(i - 1)
      }
      
      seq.2 <- NULL
      if (i + 1 <= p) {
        seq.2 <- (i + 1):p
      }
      
      s <- c(seq.1, seq.2, i)
      S.part <- S[s, s]
      W.part <- W[s, s]
      T.inv.part <- T.inv[s, s]
      
      W.xx <- W.part[1:(p - 1), 1:(p - 1)]
      W.xy <- W.part[1:(p - 1), p]
      
      S.xx <- S.part[1:(p - 1), 1:(p - 1)]
      S.xy <- matrix(S.part[1:(p - 1), p], ncol = 1)
      S.yy <- as.double(S.part[p, p])
      
      T.inv.xy <- T.inv.part[1:(p - 1), p]
      
      ## update W.12
      C.inv <- solve(W.xx) * (S.yy + lambda) + diag(T.inv.xy)
      R.C <- chol(C.inv)
      z <- forwardsolve(t(R.C), S.xy)
      m <- backsolve(R.C, z)
      mu <- -t(m)
      r.n <- matrix(rnorm(p - 1), ncol = 1)
      z <- backsolve(R.C, r.n)
      W.xy <- matrix(t(z) + mu, ncol = 1)
      gam <- (S.yy + lambda)^(-1) * rchisq(1, n)
      W.yy <- gam + as.double(t(W.xy) %*% solve(W.xx, W.xy))
      
      ## update W
      W[i, i] <- W.yy
      if (i - 1 >= 1) {
        W[i, 1:(i - 1)] <- W.xy[1:(i - 1), 1]
        W[1:(i - 1), i] <- W[i, 1:(i - 1)]
      }
      if (p >= i + 1) {
        W[i, (i + 1):p] <- W.xy[i:(p - 1), 1]
        W[(i + 1):p, i] <- W[i, (i + 1):p]
      }
    }
    
    ## update T.inv
    for (l in 1:(p - 1)) {
      for (j in (l + 1):p) {
        T.inv[l, j] <- inverseGaussian(lambda/abs(W[l, j]), lambda^2)
        T.inv[j, l] <- T.inv[l, j]
      }
    }
    
    if (nscan > burnin) {
      W.avg <- W.avg + W
    }
    
    MB.arr[nscan, ] <- as.vector(W[(1:p.1), (p.1 + 1):(p.1 + p.2)])
  }   # end of NSCAN loop

  return(list( MB.arr = MB.arr,
               W.avg  = W.avg ))
}




HoffMB <- function(S, n, p, q, NSCAN, lambda, n0) {
  # This is the subroutine for the Markov blanket estimation.
  # (Hoff-Gaussian-Copula framework not used here, because matrix S is continuous)
  # It is invoked from 'BMB()'.
  #
  # ARGS:
  #     S        : covariance 
  #     n        : number of observations
  #     p, q     : number of nodes in the '12' and '22' part of the covariance matrix,
  #              : i.e. p + q is number of nodes in the network
  #     NSCAN    : number of MCMC samples
  #     lambda   : sparsity parameter > 0, higher = more penalty on number of edges
  #     n0       : n0 = 0 by default
  #
  # RETURNS:
  #     list object containing:   (i) MB.arr : ---

  S.xx <- S[1:p, 1:p, drop = FALSE]
  S.xy <- S[1:p, (p + 1):(p + q), drop = FALSE]
  S.yy <- S[(p + 1):(p + q), (p + 1):(p + q), drop = FALSE]
  
  S.yy.lambda <- S.yy
  diag(S.yy.lambda) <- diag(S.yy.lambda) + lambda
  
  B0 <- diag(lambda, p + q, p + q)
  B <- rWishart(1, n + n0, solve(S + B0))[, , 1]
  
  B.xx <- B[1:p, 1:p, drop = FALSE]
  B.yy <- B[(p + 1):(p + q), (p + 1):(p + q), drop = FALSE]
  B.xy <- B[1:p, (p + 1):(p + q), drop = FALSE]
  
  T.inv <- matrix(rnorm(p * q), p, q)
  
  MB.arr <- matrix(0, NSCAN, p * q)
  
  ### Gibbs sampling scheme, main loop
  for (nscan in 1:NSCAN) {
    MB <- MarkovBlanketKDsparseOneDraw(n = n, n0 = n0, S.xx = S.xx, S.xy = S.xy, S.yy.lambda = S.yy.lambda, W.xx = B.xx, W.xy = B.xy, W.yy = B.yy, T.inv = T.inv, lambda = lambda, do.yy = FALSE)
    B.xx <- MB$W.xx
    B.xy <- MB$W.xy
    B.yy <- MB$W.yy
    T.inv <- MB$T.inv
    
    MB.arr[nscan, ] <- as.vector(B.xy)
  }
  
  return(list( MB.arr = MB.arr ))
}




BMB <- function(S, n, p, q, lambda, NSCAN, burnin, thresh.low) {
  # This is the function call for the Bayesian Markov Blanket estimation (BMB).
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     S          : sample covariance 
  #     n          : number of observations
  #     p, q       : number of nodes in the '12' and '22' part of the covariance matrix,
  #                : i.e. p + q is number of nodes in the network
  #     lambda     : sparsity parameter > 0, higher = more penalty on number of edges
  #     NSCAN      : number of MCMC samples
  #     burnin     : number of burn-in samples
  #     thresh.low : defines the credibility interval by: 1 - thresh.low
  #
  # RETURNS:
  #     MB.BMB : Markov blanket based on Bayesian Graphical Lasso, p x q matrix
  
  MB.BMB <- HoffMB(S = S * n, n = n, p = p, q = q, NSCAN = NSCAN, lambda = lambda, n0 = 0)$MB.arr[(burnin + 1):NSCAN, ]
  MB.BMB = threshold.matrix(MB.BMB, thresh.low, p, q)

  return(MB.BMB)
}




BGL <- function(S, n, p, q, lambda, NSCAN, burnin, thresh.low) {
  # This is the function call for the Bayesian Graphical Lasso (BGL).
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     S          : covariance 
  #     n          : number of observations
  #     p, q       : number of nodes in the '12' and '22' part of the covariance matrix,
  #                : i.e. p + q is number of nodes in the network
  #     lambda     : sparsity parameter > 0, higher = more penalty on number of edges
  #     NSCAN      : number of MCMC samples
  #     burnin     : number of burn-in samples
  #     thresh.low : defines the credibility interval by: 1 - thresh.low
  #
  # RETURNS:
  #     MB.BGL : Markov blanket based on Bayesian Graphical Lasso, p x q matrix
  
  MB.BGL <- Bayes.glasso.MB(S = S * n, n = n, lambda = lambda, NSCAN = NSCAN, burnin = burnin, p.1 = p, p.2 = q)$MB.arr[(burnin + 1):NSCAN, ]
  MB.BGL = threshold.matrix(MB.BGL, thresh.low, p, q)
  
  return(MB.BGL)
}




threshold.matrix <- function(MB, thresh.low, p, q) {
  # This subroutine computes the final Markov blanket based on credibility (1 - thresh.low).
  # It is invoked from 'BMB()' and 'BGL()'.
  #
  # ARGS:
  #     MB         : Markov blanket, matrix with dimensions p x (p+q)
  #     thresh.low : defines the credibility interval by: 1 - thresh.low
  #     p, q       : number of nodes in the '12' and '22' part of the covariance matrix,
  #                : i.e. p + q is number of nodes in the network
  #
  # RETURNS:
  #     MB.mat : final Markov blanket, p x q matrix

  qua <- c(thresh.low, 0.5, 1 - thresh.low)
  CI <- apply(MB, 2, quantile, qua)
  CI.sign <- apply(CI, 2, function(x) {
    x[1] * x[3]
  })
  MB.vec <- rep(0, p * q)
  w <- which(CI.sign > 0)
  MB.vec[w] <- CI[2, w]
  MB.mat <- matrix(MB.vec, nrow = p)
  
  return(MB.mat)
}




inverseGaussian <- function(mu, lambda) {
  # Sampling from an inverse Gaussian distribution.
  # It is invoked from 'Bayes.glasso.MB()'.
  #
  # ARGS:
  #     mu     : (positive) mean
  #     lambda : (positive) precision parameter
  #
  # RETURNS:
  #     s : double representing a draw from the inv. Gaussian distribution
  
  v <- rnorm(1)   # sample from a normal distribution with a mean of 0 and 1 standard deviation
  y <- v * v
  x <- mu + (mu * mu * y)/(2 * lambda) - (mu/(2 * lambda)) * sqrt(4 * mu * lambda * y + mu * mu * y * y)
  test <- runif(1)   # sample from a uniform distribution between 0 and 1
  
  if (test <= (mu)/(mu + x)) {
    s <- x
  }
  else {
    s <- (mu * mu)/x
  }
  
  return(s)
}




block.chol.BWD <- function(B, W, D) {  
  # This subroutine returns the upper Cholesky factor L^t
  # It is invoked from 'MarkovBlanketKDsparseOneDraw()'.
  #
  # ARGS:
  #     B : S.22 part of S with the sparsity parameter added to the diagonal
  #     W : for definition see function 'HoffMB()'
  #     D : T.inv <- matrix(rnorm(p * q), p, q), see function 'HoffMB()'
  #
  # RETURNS:
  #     L.t : upper Cholesky factor (matrix)
  
  W <- as.matrix(W)
  if (!is.matrix(D)) {
    D <- matrix(D, nrow = 1)
  }
  K <- ncol(W)
  n.K <- nrow(B)
  L.d <- n.K * K
  L.t <- matrix(0, L.d, L.d)
  for (start in 1:K) {
    L.start.t <- chol(W[start, start] * B + diag(D[start, ]))
    L.row.t <- L.start.t
    block.unweighted <- forwardsolve(t(L.start.t), B)
    if ((start + 1) <= K) {
      for (i in (start + 1):K) {
        L.row.t <- cbind(L.row.t, W[start, i] * block.unweighted)
      }
    }
    L.t[((start - 1) * n.K + 1):(start * n.K), ((start - 1) * n.K + 1):L.d] <- L.row.t
  }
  
  return(L.t)
}




MarkovBlanketKDsparseOneDraw <- function(n, n0, S.xx, S.xy, S.yy.lambda, W.xx, W.xy, W.yy, T.inv, lambda, do.yy = TRUE) {
  # This subroutine calculates...
  # It is invoked from 'HoffMB()'.
  #
  # ARGS:
  #     n           : number of observations
  #     n0          : n0 = 0 by default
  #     S.xx        : S.11 part of S
  #     S.xy        : S.12 part of S
  #     S.yy.lambda : S.22 part of S with the sparsity parameter added to the diagonal
  #     W.xx        : -- see variable B.xx in 'HoffMB()'
  #     W.xy        : -- see variable B.xy in 'HoffMB()'
  #     W.yy        : -- see variable B.yy in 'HoffMB()'
  #     T.inv       : random normal matrix with dimensions p x q
  #     lambda      : sparsity parameter > 0, higher = more penalty on number of edges
  #     do.yy       : TRUE by default, here set to FALSE in "HoffMB()"
  #
  # RETURNS:
  #     list object containing:   (i) W.xx = W.xx   : --
  #                              (ii) W.xy = W.xy   : --
  #                             (iii) W.yy = W.yy   : --
  #                              (iv) T.inv = T.inv : --
  
  ## one draw from and Graph-Lasso
  W.prior <- diag(lambda, nrow(S.xx))
  p <- nrow(S.xx)
  q <- ncol(S.yy.lambda)
  df <- 0.5 * (n + n0) + 1   # n0: default = 0
  
  r.n <- rnorm(q * p)
  
  R.C <- block.chol.BWD(S.yy.lambda, solve(W.xx), T.inv)
  z <- forwardsolve(t(R.C), as.vector(t(S.xy)))
  m <- backsolve(R.C, z)  ## m is the (negative) mean
  z <- backsolve(R.C, r.n)  ## z ~ N(0, C^(-1))   
  ## z - m ~ N(-C^(-1) vec(S.xy), C^(-1))
  
  W.xy <- t(z) - t(m)
  W.xy <- matrix(W.xy, nrow = p, byrow = TRUE)
  W.xx <- MGIG(df, S.xx + W.prior, W.xy %*% S.yy.lambda %*% t(W.xy), iter = 40)$Z
  
  for (l in 1:p) {
    for (j in 1:q) {
      T.inv[l, j] <- inverseGaussian(lambda/abs(W.xy[l, j]), lambda^2)
    }
  }
  
  if (do.yy) {
    W.yy.x <- rWishart(1, n + n0, solve(S.yy.lambda))[, , 1]
    W.yy <- W.yy.x + t(W.xy) %*% solve(W.xx, W.xy)
  }
  else {
    W.yy <- diag(1, q)
  }
  
  return(list( W.xx = W.xx,
               W.xy = W.xy,
               W.yy = W.yy,
               T.inv = T.inv ))
}




measure.time <- function(time.start = NULL) {
  # This subroutine measure the elapsed time in seconds.
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     time.start : starting time, defaults to NULL 
  #
  # RETURNS:
  #     prints the elpased time to the screen

  if (is.null(time.start)[1]) {
    return(proc.time())
  } else {
    time.stop <- proc.time()
    time.delta <- (time.stop - time.start)[[3]]
    cat(sprintf('elapsed time: %.3f seconds\n\n', time.delta))
  }
}




generate.graph <- function(MB) {
  # Given the Markov blanket, this subroutine generates the underlying graph for plotting.
  # It is invoked from 'main()'.
  #
  # ARGS:
  #     MB : Markov blanket, matrix with dimensions p x q
  #
  # RETURNS:
  #     graph : list containing the graph data (see 'igraph' package)
    
  p = nrow(MB)
  q = ncol(MB)
  
  W = matrix(0, nrow = (p + q), ncol = (p + q))
  W[1:p, (p + 1):(p + q)] = MB
  W[(p + 1):(p + q), 1:p] = MB
  
  graph <- graph.adjacency(abs(W), weighted = TRUE, mode = 'undirected')
  signMat <- sign(W)
  e.names <- get.edgelist(graph)
  edge.signs <- rep(0, nrow(e.names))
  edge.weights <- rep(0, nrow(e.names))
  
  if (nrow(e.names) > 0) {
    for (j in 1:nrow(e.names)) {
      edge.signs[j] <- signMat[e.names[j, 1], e.names[j, 2]]
      edge.weights[j] <- abs(W[e.names[j, 1], e.names[j, 2]])
    }
    edge.weights <- edge.weights / max(edge.weights) * 6
  }
  
  V(graph)$label <- ''
  V(graph)$color <- c(rep('red', p), rep('white', q))
  V(graph)$size <- 6
  E(graph)$width <- edge.weights
  
  edge.colors <- rep(NA, length(edge.signs))
  edge.colors[which(edge.signs == 1)] <- 'black'
  edge.colors[which(edge.signs == -1)] <- 'grey'
  E(graph)$color <- edge.colors
  
  return(graph)
}