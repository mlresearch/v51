#####################################################################################
# DELETE IN FINAL VERSION                                                           #

  # General Layout and Ordering
  #
  # 1. Copyright statement comment
  # 2. Author comment
  # 3. File description comment, including purpose of program, inputs, and outputs
  # 4. source() and library() statements
  # 5. Function definitions
  # 6. Executed statements, if applicable (e.g., print, plot)

# DELETE IN FINAL VERSION                                                           #
#####################################################################################





###########################################################################################
# Copyright (c) 2015, All Right Reserved, http://www.ourGroup.xy                          #
#                                                                                         #
# This source is subject to the Microsoft Permissive License.                             #
# Please see the License.txt file for more information.                                   #
# All other rights reserved.                                                              #
#                                                                                         #
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY                  #
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE                     #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                              #
# PARTICULAR PURPOSE.                                                                     #
#                                                                                         #
# author: tba                                                                             #
# email : tba                                                                             #
# date  : 2015-05-15                                                                      #
# <summary> ... </summary>                                                                #
###########################################################################################

### clear the workspace

rm(list = ls())



### source() and library() statements

source("functions.R")

library(VGAM)
library(igraph)



##################
# PROGRAM: START #
##################
#
# ARGS:
#     n        : number of observations
#     p, q     : number of nodes in the '12' and '22' part of the covariance matrix,
#              : i.e. p + q is number of nodes in the network
#
# RETURNS:
#     result.pdf : pdf file containing graphs of (i)   true Markov blanket
#                                                (ii)  Bayesian Markov Blanket Estimation (BMB)
#                                                (iii) Bayesian Graphical Lasso Estimation (BGL)
#
#
### initialize variables
p <- 10
q <- 30
n <- (p + q) * 10


### generate artificial data
 D <- sample.gauss.wishart(p = p, q = q, min.edge.12 = 10, max.edge.12 = 15, min.edge.22 = 20, max.edge.22 = 80, f.dim = n, f.d.term = 0.1)
 X <- D$data
 S <- cov.from.normscores(X)

 inv.cov <- D$inv.cov   # corresponds to precision matrix W in the paper
 MB.true <- inv.cov[1:p, (p + 1):(p + q)]   # to be inferred


### inference
 NSCAN <- 500   # number of MCMC samples
 burnin <- floor(0.3 * NSCAN)   # number of MCMC samples for burnin
 thresh.low <- 0.15   # credibility interval: 1 - thresh.low
 lambda <- 70   # sparsity parameter > 0, higher = more penalty on number of edges

 cat(sprintf('parameters: lambda = %d, NSCAN = %d, burnin = %d, thresh.low = %.2f\n\n', lambda, NSCAN, burnin, thresh.low))


### RUN: Bayesian Markov Blanket Estimation
 cat('running BMB... ')
 time.start <- measure.time()
 MB.BMB <- BMB(S = S, n = n, p = p, q = q, lambda = lambda, NSCAN = NSCAN, burnin = burnin, thresh.low = thresh.low)
 cat('done\n')
 measure.time(time.start) # prints elapsed time


### RUN: Bayesian Graphical Lasso
 cat('running BGL... ')
 time.start <- measure.time()
 MB.BGL <- BGL(S = S, n = n, p = p, q = q, lambda = lambda, NSCAN = NSCAN, burnin = burnin, thresh.low = thresh.low)
 cat('done\n')
 measure.time(time.start)


### PLOT RESULTS
 pdf('result.pdf', width = 9, height = 3)

 layout(matrix(1:3, nrow = 1, ncol = 3, byrow = TRUE))
 par(mar = c(0.0, 0.0, 0.0, 0.0), mai = c(0, 0, 0.15, 0), oma = c(0, 0, 0.5, 0))

 # plot True Markov Blanket
 g.true <- generate.graph(MB.true)
 layout <- layout.circle(g.true)
 plot(g.true, layout = layout, main = 'true Markov blanket')

 # plot Bayesian Markov Blanket Estimation
 g.BMB <- generate.graph(MB.BMB)
 plot(g.BMB, layout = layout, main = 'BMB')

 # plot Bayesian Graphical Lasso Estimation
 g.BGL <- generate.graph(MB.BGL)
 plot(g.BGL, layout = layout, main = 'BGL')

 dev.off()


################
# PROGRAM: END #
################