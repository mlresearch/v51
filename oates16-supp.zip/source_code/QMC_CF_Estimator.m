% Quasi-Monte Carlo + Control Functionals

function mu_hat = QMC_CF_Estimator(ndim,f,n,k,qmc_set)

if k == 0
    % Tensor product of Wendland functions (k=0)
    phi = @(r) 1 - r;
    k = @(x,y) prod(phi(abs(repmat(x,size(y,1),1)-repmat(y,size(x,1),1))),2);
    int_k = @(y) prod((1/2) + y - y.^2,2);
elseif k == 1 
    % Tensor product of Wendland functions (k=1)
    phi = @(r) (1-r).^3 .* (3*r + 1);
    k = @(x,y) prod(phi(abs(repmat(x,size(y,1),1)-repmat(y,size(x,1),1))),2);
    int_k = @(y) prod((2/5) + y - 2*y.^3 + y.^4,2);
elseif k == 2
    % Tensor product of Wendland functions (k=2)
    phi = @(r) (1-r).^5 .* (24*r.^2 + 15*r + 3);
    k = @(x,y) prod(phi(abs(repmat(x,size(y,1),1)-repmat(y,size(x,1),1))),2);
    int_k = @(y) prod(1 + 3*y - 7*y.^3 + 21*y.^5 - 35*y.^6 + 24*y.^7 -6*y.^8,2);
end

% uniform grid
x_train = uniform_grid(ceil(n/2),ndim);

% low discrepancy point set (Halton set with scrambling)
if qmc_set == 'h'
    p = haltonset(ndim);
    p = scramble(p,'RR2');
elseif qmc_set == 's'
    p = sobolset(ndim);
    p = scramble(p,'MatousekAffineOwen');
end
x_test = p(1:ceil(n/2),:);
x_test = rem(bsxfun(@plus,x_test,rand(1,ndim)),1); % random shift

% estimation
mu_hat = QMC_CF(f,x_train,x_test,k,int_k);

end

function mu_hat = QMC_CF(f,x_train,x_test,k,int_k)
% solve the linear system
N = size(x_train,1);
f_train = zeros(N,1);
for i = 1:N
    f_train(i) = f(x_train(i,:));
end
K = pdist2(x_train,x_train,k);
alpha = K \ f_train;

% functional approximation
M = size(x_test,1);
f_N = zeros(M,1);
f_test = zeros(M,1);
for i = 1:M
    for j = 1:N
        f_N(i) = f_N(i) + alpha(j)*k(x_test(i,:),x_train(j,:));
    end
    f_test(i) = f(x_test(i,:));
end

% % display
% figure(123)
% for i = 1:N
%     plot3(x_train(i,1),x_train(i,2),f_train(i),'kx');
%     hold on
% end
% for i = 1:M
%     plot3(x_test(i,1),x_test(i,2),f_test(i),'rx');
%     plot3(x_test(i,1),x_test(i,2),f_N(i),'ro');
% end
% pause()
% hold off
% clf

% analytic integral
I_f_N = 0;
for i = 1:N
    I_f_N = I_f_N + alpha(i) * int_k(x_train(i,:));
end

% control functional
psi = f_N - I_f_N;

% QMC_CF estimator
mu_hat = mean(f_test - psi);
end









