% Standard Quasi-Monte Carlo

function mu_hat = QMC_Estimator(ndim,f,n)

% low discrepancy point set with randomisation for QMC CF
p = haltonset(ndim);
p = scramble(p,'RR2');
x_vals = p(1:n,:);
x_vals = rem(bsxfun(@plus,x_vals,rand(1,ndim)),1);

% estimation
f_vals = zeros(n,1);
for i = 1:n
    f_vals(i) = f(x_vals(i,:));
end
mu_hat = mean(f_vals);

end









