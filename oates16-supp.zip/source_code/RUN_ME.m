%% Settings
k = str2double(inputdlg('Please input k, the order of the Wendland kernel (options are 0,1,2)','Settings',1,{'1'})); % order for the Wendland kernel
qmc_set = inputdlg('Which QMC points should I use? (options are h = Halton, s = Sobol)','Settings',1,{'h'}); % point set to use
qmc_set = qmc_set{1};
dims = [1 2 3 4]; % dimension of the integrands
functions = [1 2 3 4 5 6]; % default is to use all te Genz functions
num_ns = 7; % number of N values to consider
num_reps = 10; % number of replicates to consider

%% Compute the results first:
num_dims = length(dims);
num_functions = length(functions);
se_QMC = zeros(num_dims,num_functions,num_ns,num_reps);
se_QMC_CF = zeros(num_dims,num_functions,num_ns,num_reps);
for d = 1:num_dims % dimensionality of the problem
    dim = dims(d);
    multiWaitbar('Dimension',d/num_dims);
    for index = functions % different test functions
        multiWaitbar('Test Function',index/length(functions));
        for rep = 1:num_reps % replicates
            multiWaitbar('Replicate',rep/num_reps);
            
            %% Define the test function
            startingpoint = zeros(1,dim); %the lower limits of the integral
            endingpoint = ones(1,dim); %the upper limits of the integral
            hyperbox = [startingpoint;endingpoint]; % the integration interval
            alpha = ones(1,dim);
            beta = 1./ (1:dim); 
            r = 2; % three coefficients in genz_test_fun and genz_test_fun_true
            f = @(x) genz_test_fun(x,index,dim,alpha,beta,r); % test function
            I = genz_test_fun_true(hyperbox,index,dim,alpha,beta,r); % true integral

            %% Numerical integration
            n_vals{d} = 2.^(1:num_ns);
            for ni = 1:length(n_vals{d})
                n = n_vals{d}(ni);
                mu_hat_QMC = QMC_Estimator(dim,f,n); % standard QMC
                mu_hat_QMC_CF = QMC_CF_Estimator(dim,f,n,k,qmc_set); % proposed approach
                se_QMC(d,index,ni,rep) = (mu_hat_QMC - I)^2; % square error QMC
                se_QMC_CF(d,index,ni,rep) = (mu_hat_QMC_CF - I)^2; % square error QMC_CF
            end
        end
    end 
end
multiWaitbar( 'CloseAll' );

%% Display the results
mse_QMC = mean(se_QMC,4);
mse_QMC_CF = mean(se_QMC_CF,4);
se_mse_QMC = std(se_QMC,0,4) / sqrt(num_reps); % standard error of the MSE
se_mse_QMC_CF = std(se_QMC_CF,0,4) / sqrt(num_reps); % standard error of the MSE
function_names = {'Oscillatory','Product Peak','Corner Peak',...
                  'Gaussian','Continuous','Discontinuous'};
set_names = {'Halton Set','Sobol Set'};
if qmc_set == 'h'
    set_name = set_names{1};
elseif qmc_set == 's'
    set_name = set_names{2};
end
shape = {'o','^','s','*'}; col = {'k','b','r','g'};
for index = functions
    figure(index)
    hold on
    for d = 1:num_dims
        errorbar(n_vals{d},squeeze(mse_QMC(d,index,:)),...
                 squeeze(se_mse_QMC(d,index,:)),[col{d},'-',shape{d}]); 
        set(gca,'XScale','log'); % set the X axis in log scale.
        set(gca,'YScale','log'); % set the X axis in log scale.
        errorbar(n_vals{d},squeeze(mse_QMC_CF(d,index,:)),...
                 squeeze(se_mse_QMC_CF(d,index,:)),[col{d},':',shape{d}]);
        set(gca,'XScale','log'); % set the X axis in log scale.
        set(gca,'YScale','log'); % set the X axis in log scale.
        set(gca,'XLim',[min(n_vals{d}) max(n_vals{d})]);
    end
    title([function_names{index},' Test Function (',set_name,', k = ',num2str(k,'%d'),')'])
    xlabel('Num. Function Evaluations (N)')
    ylabel('Mean Square Error')
    box on;
    set(gcf,'color','w');
    set(gcf, 'Position', [200 200 500 350]);
    set(gca,'xtick',[1:9,10:10:130])
    set(gca,'xticklabel',{'1','2','3','4','...','','','','','10','20','30','40','...','','','','','100','','','...'})
    gridxy(get(gca,'xtick'),get(gca,'ytick'),'color',[.6 .6 .6],'linewidth',1)
end






