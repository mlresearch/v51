function grid = uniform_grid(npoints,ndim)
L = ceil(npoints^(1/ndim));
xis = linspace(0,1,L)';
grid = zeros(npoints,ndim);
for i = 1:ndim
    grid(1:(L^ndim),i) = kron(repmat(xis,L^(i-1),1),ones(L^(ndim-i),1));
end
end