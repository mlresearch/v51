Supplemental Materials for AISTATS 2016 paper:
“C3: Lightweight Incrementalized MCMC for Probabilistic Programs using Continuations and Callsite Caching”


Archive Contents
- - - - - - - - -

/data: Raw data from all experiments reported in the paper.
  - hmm: data for the HMM plots in Figure 4.
  - hmm: data for the LDA plots in Figure 4.
  - procmod: data for the procedural modeling plots in Figure 5.
  - speedups: data for the speedup plots in Figure 6.

/code: Source code for all programs used in the paper. *.wppl files are probabilistic programs. *.js files are deterministic javascript libraries.

/cps_example: an example program, before and after transformation into continuation-passing style.


Details of Speedup Experiment (Figure 6)
- - - - - - - - - - - - - - - - - - - - -

All models use synthetic data. To obtain the throughput values plotted, each model was run for 1000 MH iterations.

The HMM model uses 10 discrete latent states and 10 discrete observable states. The Model Size parameter maps to the length of the observed sequence as: Length of observed sequence = 100 * Model Size. Thus, observed sequence length ranges from 100 to 1000.

The LDA model uses 10 topics, a vocabulary of 100 words, and 20 words per document. The Model Size parameter maps to the number of observed documents as: Num observed documents =  5 * Model Size. Thus, num observed documents ranges from 5 to 50, and total number of observed words ranges from 100 to 1000.

The GMM model uses 4 components. The Model Size parameter maps to the number of observed data points as: Num observed data points = 100 * Model Size. Thus, the number of observed data points ranges from 100 to 1000.

The HLR model uses scalar data sequences of length 5. The Model Size parameter maps to the number of data sequences as: Num data sequences = 20 * Model Size. Thus, the number of data sequences ranges from 20 to 200, and the total number of scalar data points ranges from 100 to 1000.