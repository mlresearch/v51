var fs = require('fs');
var util = require('../src/util.js');

function genSynthData(nDocs, nWords, nWordsPerDoc) {
	var gensym = util.makeGensym();
	var vocab = [];
	for (var i = 0; i < nWords; i++)
		vocab.push(gensym('word'));
	var docs = [];
	for (var i = 0; i < nDocs; i++) {
		var doc = [];
		var wordsLeft = nWordsPerDoc;
		var wordsToChoose = [];
		for (var j = 0; j < nWords; j++)
			wordsToChoose.push(j);
		while (wordsLeft > 0) {
			var wordIdx = Math.floor(Math.random() * wordsToChoose.length);
			var word = wordsToChoose[wordIdx];
			wordsToChoose.splice(wordIdx, 1);
			var n = Math.ceil(Math.random()*wordsLeft);
			wordsLeft -= n;
			doc.push([word, n]);
		}
		docs.push(doc);
	}
	return {vocab: vocab, documents: docs};
}

module.exports = {
	genSynthData: genSynthData
};
